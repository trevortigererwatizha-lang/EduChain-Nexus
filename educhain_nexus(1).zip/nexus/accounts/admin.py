from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import User


@admin.register(User)
class NexusUserAdmin(UserAdmin):
    fieldsets = UserAdmin.fieldsets + (("Nexus", {"fields": ("role", "status", "reg_note", "decided_at", "decided_by", "decision_note")}),)
    list_display = ("username", "first_name", "last_name", "role", "status", "is_active", "registered_at")
    list_filter = ("status", "role", "is_active")
    actions = ["approve", "reject"]

    @admin.action(description="Approve selected registrations")
    def approve(self, request, qs):
        from django.utils import timezone
        n = qs.filter(status="pending").update(status="approved", is_active=True, decided_at=timezone.now(), decided_by=request.user)
        self.message_user(request, f"{n} registration(s) approved.")

    @admin.action(description="Reject selected registrations")
    def reject(self, request, qs):
        from django.utils import timezone
        n = qs.filter(status="pending").update(status="rejected", is_active=False, decided_at=timezone.now(), decided_by=request.user)
        self.message_user(request, f"{n} registration(s) rejected.")
