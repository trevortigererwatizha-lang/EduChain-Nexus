from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils import timezone


class User(AbstractUser):
    class Role(models.TextChoices):
        ADMIN = "admin", "Administrator"
        STUDENT = "student", "Student"
        TEACHER = "teacher", "Teacher"
        ALUMNI = "alumni", "Alumni"
        PARTNER = "partner", "Recruiter or university"

    class Status(models.TextChoices):
        PENDING = "pending", "Awaiting approval"
        APPROVED = "approved", "Approved"
        REJECTED = "rejected", "Not approved"

    role = models.CharField(max_length=10, choices=Role.choices, default=Role.STUDENT)
    # Existing, imported and admin-created accounts are approved. Only self-registration sets 'pending'.
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.APPROVED, db_index=True)
    registered_at = models.DateTimeField(default=timezone.now)
    reg_note = models.CharField(max_length=300, blank=True, help_text="what the person wrote when registering")
    decided_at = models.DateTimeField(null=True, blank=True)
    decided_by = models.ForeignKey("self", null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    decision_note = models.CharField(max_length=200, blank=True)

    @property
    def is_data_admin(self):
        return self.is_superuser or self.role == self.Role.ADMIN

    @property
    def display(self):
        return self.get_full_name() or self.username
