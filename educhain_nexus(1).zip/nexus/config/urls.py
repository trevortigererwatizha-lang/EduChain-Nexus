from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.urls import include, path

from web.forms import LoginForm

urlpatterns = [
    path("admin/", admin.site.urls),
    path("login/", auth_views.LoginView.as_view(template_name="web/login.html", redirect_authenticated_user=True, authentication_form=LoginForm), name="login"),
    path("logout/", auth_views.LogoutView.as_view(), name="logout"),
    path("data/", include("datahub.urls")),
    path("", include("web.urls")),
]
