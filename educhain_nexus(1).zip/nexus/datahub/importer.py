"""Two-step CSV import: validate and preview, then commit atomically."""
import hashlib

from django.contrib.auth import get_user_model
from django.db import transaction

from engine import csvio
from hub import services
from hub.models import (Activity, AlumniProfile, Award, Event, ImportJob, Listing, Profile, Project, School)

User = get_user_model()
MAX_STORED = 200


class ImportError_(Exception):
    pass


def _add(errs, line, col, msg):
    if len(errs) < MAX_STORED:
        errs.append({"line": line, "field": col, "message": msg})


def check_against_db(kind, res):
    """Rules that need the database. Import order is schools, students, projects, activity, awards, events, alumni, listings."""
    errs = res.errors
    schools = set(School.objects.values_list("code", flat=True))
    users = dict(User.objects.values_list("username", "role"))
    projects = set(Project.objects.values_list("slug", flat=True))
    if kind in ("students", "alumni"):
        for r in res.rows:
            if r["school_code"] not in schools:
                _add(errs, r["_line"], "school_code", f"unknown school '{r['school_code']}'. Import schools first.")
            want = "student" if kind == "students" else "alumni"
            if users.get(r["username"], want) not in (want,):
                _add(errs, r["_line"], "username", f"'{r['username']}' already belongs to a {users[r['username']]} account.")
    elif kind in ("projects", "listings"):
        for r in res.rows:
            if r["owner_username"] not in users:
                _add(errs, r["_line"], "owner_username", f"no user '{r['owner_username']}'. Import students first.")
    elif kind == "activity":
        incoming = set()
        for r in res.rows:
            if r["project_slug"] not in projects:
                _add(errs, r["_line"], "project_slug", f"unknown project '{r['project_slug']}'. Import projects first.")
            if r["author_username"] not in users:
                _add(errs, r["_line"], "author_username", f"no user '{r['author_username']}'.")
    elif kind == "awards":
        for r in res.rows:
            if r["username"] not in users:
                _add(errs, r["_line"], "username", f"no user '{r['username']}'. Import students first.")
    elif kind == "events":
        for r in res.rows:
            if r["school_code"] and r["school_code"] not in schools:
                _add(errs, r["_line"], "school_code", f"unknown school '{r['school_code']}'.")
    return res


def start_preview(kind, filename, data, user):
    text = data.decode("utf-8-sig", errors="replace") if isinstance(data, bytes) else data
    sha = hashlib.sha256(text.encode()).hexdigest()
    res = csvio.parse(kind, text)
    if not res.errors:
        check_against_db(kind, res)
    ok = res.ok
    job = ImportJob.objects.create(kind=kind, filename=(filename or "upload.csv")[:200], sha256=sha, raw=text if ok else "", user=user,
                                   rows_total=res.total_rows, errors=res.errors[:MAX_STORED],
                                   status=ImportJob.Status.PREVIEWED if ok else ImportJob.Status.FAILED)
    return job, res


def _names(full):
    parts = full.split()
    return parts[0][:150], " ".join(parts[1:])[:150]


@transaction.atomic
def commit(job):
    job = ImportJob.objects.select_for_update().get(pk=job.pk)
    if job.status != ImportJob.Status.PREVIEWED:
        raise ImportError_("This upload has already been handled.")
    res = csvio.parse(job.kind, job.raw)
    if not res.errors:
        check_against_db(job.kind, res)
    if not res.ok:
        job.status, job.errors, job.raw = ImportJob.Status.FAILED, res.errors[:MAX_STORED], ""
        job.save()
        raise ImportError_("The data changed since the preview and no longer validates. Nothing was imported.")
    created = updated = 0
    kind = job.kind
    schools = {s.code: s for s in School.objects.all()}
    users = {u.username: u for u in User.objects.all()}
    for r in res.rows:
        if kind == "schools":
            _, new = School.objects.update_or_create(code=r["school_code"], defaults={"name": r["name"], "city": r["city"] or "", "country": r["country"] or "", "motto": r["motto"] or ""})
        elif kind in ("students", "alumni"):
            role = "student" if kind == "students" else "alumni"
            first, last = _names(r["full_name"])
            u, new = User.objects.get_or_create(username=r["username"], defaults={"first_name": first, "last_name": last, "role": role, "email": r.get("email") or ""})
            if new:
                u.set_unusable_password()
            else:
                u.first_name, u.last_name = first, last
                if r.get("email"):
                    u.email = r["email"]
            u.save()
            Profile.objects.update_or_create(user=u, defaults={"school": schools[r["school_code"]], "form": r.get("form") or "",
                                                               "skills": r.get("skills") or [], "interests": r.get("interests") or []})
            if kind == "alumni":
                AlumniProfile.objects.update_or_create(user=u, defaults={"graduation_year": r["graduation_year"], "university": r["university"] or "", "degree": r["degree"] or "",
                                                                         "employer": r["employer"] or "", "position": r["position"] or "", "industry": r["industry"] or "", "mentoring": bool(r["mentoring"])})
            users[u.username] = u
        elif kind == "projects":
            p, new = Project.objects.update_or_create(slug=r["slug"], defaults={"title": r["title"], "owner": users[r["owner_username"]], "category": r["category"],
                                                                               "primary_language": r["primary_language"], "description": r["description"] or "",
                                                                               "tags": r["tags"] or [], "created": r["created_date"], "base_stars": r["stars"] or 0})
            if new:
                services.anchor_project(p)
        elif kind == "activity":
            proj = Project.objects.get(slug=r["project_slug"])
            _, new = Activity.objects.get_or_create(project=proj, author=users[r["author_username"]], date=r["date"], kind=r["kind"], message=r["message"])
        elif kind == "awards":
            a, new = Award.objects.get_or_create(user=users[r["username"]], title=r["title"], date=r["date"], defaults={"award_type": r["award_type"], "issuer": r["issuer"]})
            if new:
                services.anchor_award(a)
        elif kind == "events":
            _, new = Event.objects.update_or_create(title=r["title"], start_date=r["start_date"], defaults={
                "category": r["category"], "end_date": r["end_date"], "location": r["location"] or "", "description": r["description"] or "",
                "school": schools.get(r["school_code"]) if r["school_code"] else None})
        else:
            _, new = Listing.objects.update_or_create(slug=r["slug"], defaults={"title": r["title"], "owner": users[r["owner_username"]], "category": r["category"],
                                                                              "description": r["description"] or "", "license": r["license"] or "",
                                                                              "project": Project.objects.filter(slug=r["slug"]).first()})
        created += new
        updated += not new
    job.status, job.raw = ImportJob.Status.COMMITTED, ""
    job.rows_created, job.rows_updated, job.rows_total, job.errors = created, updated, len(res.rows), []
    job.save()
    return job


def discard(job):
    if job.status == ImportJob.Status.PREVIEWED:
        job.status, job.raw = ImportJob.Status.FAILED, ""
        job.errors = [{"line": 0, "field": "", "message": "Discarded before import."}]
        job.save()
