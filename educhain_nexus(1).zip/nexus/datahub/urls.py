from django.urls import path

from . import views

app_name = "datahub"
urlpatterns = [
    path("", views.hub, name="hub"),
    path("upload/<str:kind>/", views.upload, name="upload"),
    path("preview/<int:pk>/", views.preview, name="preview"),
    path("preview/<int:pk>/confirm/", views.confirm, name="confirm"),
    path("preview/<int:pk>/discard/", views.discard, name="discard"),
    path("template/<str:kind>/", views.template, name="template"),
    path("export/<str:kind>/", views.export, name="export"),
]
