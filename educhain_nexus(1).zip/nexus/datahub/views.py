from datetime import date
from functools import wraps

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.http import Http404, HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from engine import csvio
from hub import services as S
from hub.models import (Activity, AlumniProfile, Award, Event, ImportJob, LedgerBlock, Listing, Profile, Project, School, audit)

from . import importer

EXPORTS = {**{k: v["label"] for k, v in csvio.SPECS.items()}, "scores": "Student innovation scores", "rankings": "School rankings", "ledger": "Ledger records"}


def data_admin(view):
    @wraps(view)
    @login_required
    def inner(request, *a, **kw):
        if not request.user.is_data_admin:
            raise PermissionDenied
        return view(request, *a, **kw)
    return inner


def _csv(name, body):
    r = HttpResponse(body, content_type="text/csv; charset=utf-8")
    r["Content-Disposition"] = f'attachment; filename="{name}"'
    return r


@data_admin
def hub(request):
    counts = {"schools": School.objects.count(), "students": Profile.objects.filter(user__role="student").count(), "projects": Project.objects.count(),
              "activity": Activity.objects.count(), "awards": Award.objects.count(), "events": Event.objects.count(),
              "alumni": AlumniProfile.objects.count(), "listings": Listing.objects.count()}
    specs = [{"kind": k, "label": csvio.SPECS[k]["label"], "columns": list(csvio.SPECS[k]["cols"]), "count": counts[k]} for k in csvio.ORDER]
    return render(request, "datahub/hub.html", {"nav": "data", "specs": specs, "jobs": ImportJob.objects.select_related("user")[:12],
                                                "dictionary": csvio.data_dictionary(), "reports": ["scores", "rankings", "ledger"], "labels": EXPORTS})


@data_admin
@require_POST
def upload(request, kind):
    if kind not in csvio.SPECS:
        raise Http404
    f = request.FILES.get("file")
    if not f:
        messages.error(request, "Choose a CSV file first.")
        return redirect("datahub:hub")
    if f.size > csvio.MAX_BYTES:
        messages.error(request, "That file is larger than 10 MB. Split it into smaller files.")
        return redirect("datahub:hub")
    job, res = importer.start_preview(kind, f.name, f.read(), request.user)
    audit(request.user, "import.preview", {"kind": kind, "file": job.filename, "rows": res.total_rows, "errors": len(res.errors)}, request)
    return redirect("datahub:preview", job.pk)


@data_admin
def preview(request, pk):
    job = get_object_or_404(ImportJob, pk=pk)
    res = None
    if job.status == ImportJob.Status.PREVIEWED:
        res = csvio.parse(job.kind, job.raw)
        if not res.errors:
            importer.check_against_db(job.kind, res)
    cols = list(csvio.SPECS[job.kind]["cols"])
    sample = [[("; ".join(r[c]) if isinstance(r.get(c), list) else r.get(c)) for c in cols] for r in (res.rows[:8] if res else [])]
    return render(request, "datahub/preview.html", {"nav": "data", "job": job, "label": csvio.SPECS[job.kind]["label"], "columns": cols, "res": res, "sample": sample,
                                                   "errors": res.errors if res else job.errors, "warnings": res.warnings if res else []})


@data_admin
@require_POST
def confirm(request, pk):
    job = get_object_or_404(ImportJob, pk=pk)
    try:
        job = importer.commit(job)
    except importer.ImportError_ as e:
        messages.error(request, str(e))
        return redirect("datahub:preview", pk)
    audit(request.user, "import.commit", {"kind": job.kind, "created": job.rows_created, "updated": job.rows_updated}, request)
    messages.success(request, f"Imported {job.rows_total:,} rows: {job.rows_created:,} new, {job.rows_updated:,} updated.")
    return redirect("datahub:hub")


@data_admin
@require_POST
def discard(request, pk):
    importer.discard(get_object_or_404(ImportJob, pk=pk))
    messages.info(request, "Upload discarded. Nothing was imported.")
    return redirect("datahub:hub")


@data_admin
def template(request, kind):
    if kind not in csvio.SPECS:
        raise Http404
    return _csv(f"nexus_{kind}_template.csv", csvio.write_csv(list(csvio.SPECS[kind]["cols"]), csvio.template_rows(kind)))


@data_admin
def export(request, kind):
    if kind not in EXPORTS:
        raise Http404
    cols = list(csvio.SPECS[kind]["cols"]) if kind in csvio.SPECS else None
    if kind == "schools":
        rows = [[s.code, s.name, s.city, s.country, s.motto] for s in School.objects.all()]
    elif kind == "students":
        rows = [[p.user.username, p.user.display, p.school.code if p.school else "", p.form, p.skills, p.interests, p.user.email]
                for p in Profile.objects.filter(user__role="student").select_related("user", "school")]
    elif kind == "projects":
        rows = [[p.slug, p.title, p.owner.username, p.category, p.primary_language, p.description, p.tags, p.created, p.stars] for p in Project.objects.select_related("owner")]
    elif kind == "activity":
        rows = ((a.project.slug, a.author.username, a.date, a.kind, a.message) for a in Activity.objects.select_related("project", "author").iterator())
    elif kind == "awards":
        rows = [[a.user.username, a.title, a.award_type, a.issuer, a.date] for a in Award.objects.select_related("user")]
    elif kind == "events":
        rows = [[e.title, e.category, e.start_date, e.end_date, e.location, e.school.code if e.school else "", e.description] for e in Event.objects.select_related("school")]
    elif kind == "alumni":
        rows = [[a.user.username, a.user.display, a.user.profile.school.code if getattr(a.user, "profile", None) and a.user.profile.school else "", a.graduation_year,
                 a.university, a.degree, a.employer, a.position, a.industry, "yes" if a.mentoring else "no", a.user.profile.interests if getattr(a.user, "profile", None) else []]
                for a in AlumniProfile.objects.select_related("user", "user__profile__school")]
    elif kind == "listings":
        rows = [[l.slug, l.title, l.owner.username, l.category, l.description, l.license] for l in Listing.objects.select_related("owner")]
    elif kind == "scores":
        cols = ["username", "name", "school", "innovation_score", "tier", "collaboration", "leadership", "code_quality", "projects", "stars", "verified_awards"]
        rows = [[m["user"].username, m["user"].display, m["profile"].school.code if m["profile"].school else "", m["innovation"], m["tier"], m["collaboration"],
                 m["leadership"], m["quality"], m["projects"], m["stars"], m["verified_awards"]] for m in S.all_metrics().values()]
    elif kind == "rankings":
        cols = ["rank", "school_code", "school", "score", "students", "avg_innovation", "projects", "commits_90d", "verified_awards", "participation_pct"]
        rows = [[r["rank"], r["school"].code, r["school"].name, r["score"], r["students"], r["avg"], r["projects"], r["commits"], r["awards"], r["participation"]] for r in S.school_board()]
    else:
        cols = ["index", "timestamp", "kind", "payload", "prev_hash", "hash"]
        rows = [[b.index, b.timestamp, b.kind, str(b.payload), b.prev_hash, b.hash] for b in LedgerBlock.objects.all()]
    audit(request.user, "export", {"kind": kind}, request)
    return _csv(f"nexus_{kind}_{date.today():%Y%m%d}.csv", csvio.write_csv(cols, rows))
