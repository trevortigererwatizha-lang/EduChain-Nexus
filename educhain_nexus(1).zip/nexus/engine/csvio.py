"""Spec-driven CSV validation and writing. Pure Python, no Django.
Whole file is validated first; any error means nothing is imported."""
import csv
import io
import re
from dataclasses import dataclass, field
from datetime import date, datetime

MAX_BYTES, MAX_ROWS, MAX_ERRORS = 10 * 1024 * 1024, 100_000, 200
YES, NO = {"yes", "y", "true", "1"}, {"no", "n", "false", "0"}

CATEGORIES = ["Web Application", "Mobile Application", "Machine Learning", "Robotics", "AI", "Science", "Research Paper",
              "IoT", "Blockchain", "Engineering"]
AWARD_TYPES = ["examination", "competition", "innovation", "coding", "leadership"]
EVENT_CATEGORIES = ["Academic", "Sports", "Innovation", "Alumni", "University"]
LISTING_CATEGORIES = ["Software", "Mobile Apps", "Robotics", "Games", "Websites", "Research Results"]
ACTIVITY = ["commit", "issue", "pull_request"]

# column spec: (type, required, extra)
SPECS = {
    "schools": {"label": "Schools", "key": ["school_code"], "cols": {
        "school_code": ("slug", True, 20), "name": ("text", True, 120), "city": ("text", False, 80),
        "country": ("text", False, 80), "motto": ("text", False, 160)}},
    "students": {"label": "Students", "key": ["username"], "cols": {
        "username": ("slug", True, 40), "full_name": ("text", True, 120), "school_code": ("slug", True, 20),
        "form": ("text", False, 20), "skills": ("list", False, None), "interests": ("list", False, None),
        "email": ("email", False, 120)}},
    "projects": {"label": "Projects", "key": ["slug"], "cols": {
        "slug": ("slug", True, 60), "title": ("text", True, 120), "owner_username": ("slug", True, 40),
        "category": ("choice", True, CATEGORIES), "primary_language": ("text", True, 30),
        "description": ("text", False, 600), "tags": ("list", False, None), "created_date": ("date", True, None),
        "stars": ("int", False, 100000)}},
    "activity": {"label": "Project activity", "key": ["project_slug", "author_username", "date", "kind", "message"], "cols": {
        "project_slug": ("slug", True, 60), "author_username": ("slug", True, 40), "date": ("date", True, None),
        "kind": ("choice", True, ACTIVITY), "message": ("text", True, 160)}},
    "awards": {"label": "Awards", "key": ["username", "title", "date"], "cols": {
        "username": ("slug", True, 40), "title": ("text", True, 120), "award_type": ("choice", True, AWARD_TYPES),
        "issuer": ("text", True, 120), "date": ("date", True, None)}},
    "events": {"label": "Calendar events", "key": ["title", "start_date"], "cols": {
        "title": ("text", True, 120), "category": ("choice", True, EVENT_CATEGORIES), "start_date": ("date", True, None),
        "end_date": ("date", False, None), "location": ("text", False, 120), "school_code": ("slug", False, 20),
        "description": ("text", False, 400)}},
    "alumni": {"label": "Alumni", "key": ["username"], "cols": {
        "username": ("slug", True, 40), "full_name": ("text", True, 120), "school_code": ("slug", True, 20),
        "graduation_year": ("int", True, 2100), "university": ("text", False, 120), "degree": ("text", False, 120),
        "employer": ("text", False, 120), "position": ("text", False, 120), "industry": ("text", False, 80),
        "mentoring": ("bool", False, None), "interests": ("list", False, None)}},
    "listings": {"label": "Marketplace listings", "key": ["slug"], "cols": {
        "slug": ("slug", True, 60), "title": ("text", True, 120), "owner_username": ("slug", True, 40),
        "category": ("choice", True, LISTING_CATEGORIES), "description": ("text", False, 600),
        "license": ("text", False, 60)}},
}
ORDER = ["schools", "students", "projects", "activity", "awards", "events", "alumni", "listings"]


@dataclass
class ParseResult:
    kind: str
    rows: list = field(default_factory=list)
    errors: list = field(default_factory=list)
    warnings: list = field(default_factory=list)
    total_rows: int = 0

    @property
    def ok(self):
        return not self.errors and bool(self.rows)


def _err(res, line, col, msg):
    if len(res.errors) < MAX_ERRORS:
        res.errors.append({"line": line, "field": col, "message": msg})


def parse_date(raw):
    for fmt in ("%Y-%m-%d", "%d/%m/%Y"):
        try:
            return datetime.strptime(raw.strip(), fmt).date()
        except ValueError:
            pass
    raise ValueError(f"'{raw}' is not a date. Use 2026-03-02 or 02/03/2026")


def _coerce(name, spec, raw, today):
    typ, _req, extra = spec
    raw = raw.strip()
    if typ == "text":
        if extra and len(raw) > extra:
            raise ValueError(f"longer than {extra} characters")
        return raw
    if typ == "slug":
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._\-]*", raw):
            raise ValueError("use letters, numbers, dot, dash or underscore only")
        if len(raw) > extra:
            raise ValueError(f"longer than {extra} characters")
        return raw.lower() if name != "school_code" else raw.upper()
    if typ == "email":
        if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", raw):
            raise ValueError("not an email address")
        return raw.lower()
    if typ == "int":
        if not raw.lstrip("-").isdigit():
            raise ValueError("must be a whole number")
        v = int(raw)
        if not 0 <= v <= extra:
            raise ValueError(f"must be between 0 and {extra}")
        return v
    if typ == "date":
        d = parse_date(raw)
        if d > today:
            raise ValueError(f"{d} is in the future")
        return d
    if typ == "bool":
        if raw.lower() in YES:
            return True
        if raw.lower() in NO:
            return False
        raise ValueError("must be yes or no")
    if typ == "choice":
        m = {c.lower(): c for c in extra}.get(raw.lower().replace(" ", "_") if extra is ACTIVITY else raw.lower())
        if not m:
            raise ValueError("must be one of: " + ", ".join(extra))
        return m
    if typ == "list":
        return [x.strip() for x in raw.split(";") if x.strip()]
    raise ValueError("unknown type")


def parse(kind, data, today=None):
    if kind not in SPECS:
        raise ValueError("unknown kind")
    today, spec, res = today or date.today(), SPECS[kind], ParseResult(kind)
    cols = spec["cols"]
    try:
        text = data if isinstance(data, str) else data.decode("utf-8-sig")
    except UnicodeDecodeError:
        _err(res, 0, "", "The file is not UTF-8 text. In Excel choose Save As > CSV UTF-8.")
        return res
    text = text.lstrip("﻿")
    if len(text.encode()) > MAX_BYTES:
        _err(res, 0, "", "File is larger than 10 MB. Split it into smaller files.")
        return res
    reader = csv.DictReader(io.StringIO(text))
    if not reader.fieldnames:
        _err(res, 1, "", "The file is empty or has no header row.")
        return res
    mapping = {raw: re.sub(r"[\s\-]+", "_", (raw or "").strip().lower()) for raw in reader.fieldnames}
    if len(set(mapping.values())) != len(mapping):
        _err(res, 1, "", "A column name appears twice.")
        return res
    missing = [c for c, s in cols.items() if s[1] and c not in mapping.values()]
    if missing:
        _err(res, 1, "", "Missing column(s): " + ", ".join(missing) + ". Download the template for the exact headers.")
        return res
    unknown = sorted(set(mapping.values()) - set(cols))
    if unknown:
        res.warnings.append("Ignored unknown column(s): " + ", ".join(unknown))
    seen = {}
    for line, raw in enumerate(reader, start=2):
        res.total_rows += 1
        if res.total_rows > MAX_ROWS:
            _err(res, line, "", f"More than {MAX_ROWS:,} rows. Split the file.")
            break
        if None in raw:
            _err(res, line, "", "This row has more cells than the header has columns.")
            continue
        row = {mapping[k]: (v or "").strip() for k, v in raw.items() if k is not None}
        if not any(row.values()):
            res.total_rows -= 1
            continue
        vals, bad = {}, False
        for name, sp in cols.items():
            v = row.get(name, "")
            if not v:
                if sp[1]:
                    _err(res, line, name, "is required")
                    bad = True
                vals[name] = [] if sp[0] == "list" else None
                continue
            try:
                vals[name] = _coerce(name, sp, v, today)
            except ValueError as e:
                _err(res, line, name, f"'{v}' {e}" if sp[0] not in ("date", "choice") else str(e))
                bad = True
        if kind == "events" and not bad and vals.get("end_date") and vals["end_date"] < vals["start_date"]:
            _err(res, line, "end_date", "is before the start date")
            bad = True
        if not bad:
            k = tuple(str(vals[c]) for c in spec["key"])
            if k in seen:
                _err(res, line, spec["key"][0], f"duplicate of line {seen[k]}")
            else:
                seen[k] = line
                res.rows.append({"_line": line, **vals})
    if not res.rows and not res.errors:
        _err(res, 1, "", "The file has a header but no data rows.")
    return res


def safe_cell(v):
    """Stop spreadsheet formula injection."""
    return "'" + v if isinstance(v, str) and v[:1] in ("=", "+", "-", "@", "\t", "\r") else v


def write_csv(header, rows):
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\r\n")
    w.writerow(header)
    for r in rows:
        w.writerow([safe_cell("" if v is None else ("; ".join(v) if isinstance(v, list) else v)) for v in r])
    return ("﻿" + buf.getvalue()).encode("utf-8")


def template_rows(kind):
    ex = {"schools": [["HRE01", "Harare Central High", "Harare", "Zimbabwe", "Learn, build, share"]],
          "students": [["tariro.m", "Tariro Moyo", "HRE01", "Form 5", "Python; SQL", "AI; Robotics", "tariro@example.org"]],
          "projects": [["crop-doctor", "Crop Doctor", "tariro.m", "Machine Learning", "Python", "Spots maize disease from phone photos", "ai; vision; agriculture", "2026-02-10", "3"]],
          "activity": [["crop-doctor", "tariro.m", "2026-02-11", "commit", "Add leaf classifier"]],
          "awards": [["tariro.m", "National Coding Challenge, 1st", "competition", "ZimTech", "2026-05-02"]],
          "events": [["Inter-school Hackathon", "Innovation", "2026-09-12", "2026-09-13", "Main hall", "HRE01", "48 hours to build something useful"]],
          "alumni": [["farai.c", "Farai Chuma", "HRE01", "2019", "University of Cape Town", "BSc Computer Science", "Acme Cloud", "Engineer", "Cloud", "yes", "cloud; devops"]],
          "listings": [["crop-doctor-app", "Crop Doctor app", "tariro.m", "Mobile Apps", "Free for smallholder farmers", "MIT"]]}
    return ex[kind]


def data_dictionary():
    out = []
    for kind, sp in SPECS.items():
        for c, (typ, req, extra) in sp["cols"].items():
            hint = {"choice": "one of: " + ", ".join(extra) if extra else "", "date": "2026-03-02 or 02/03/2026, not in the future",
                    "list": "several values separated by ;", "bool": "yes or no", "int": f"whole number up to {extra}",
                    "slug": "letters, numbers, . - _", "email": "email address", "text": f"text up to {extra} characters"}[typ]
            out.append({"set": sp["label"], "column": c, "required": req, "help": hint})
    return out
