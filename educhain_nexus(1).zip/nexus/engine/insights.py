"""Growth analysis and plain-English insights. Pure Python."""


def growth(old, new):
    """% change from old to new; None when there is nothing to compare with."""
    if not old:
        return None
    return round((new - old) / old * 100, 1)


def compare_counts(prev, cur, min_prev=3):
    """prev/cur: {label: count}. -> [{label, prev, cur, pct}] sorted by growth. Labels with tiny bases are flagged."""
    rows = []
    for k in set(prev) | set(cur):
        p, c = prev.get(k, 0), cur.get(k, 0)
        rows.append({"label": k, "prev": p, "cur": c, "pct": growth(p, c), "small": p < min_prev})
    return sorted(rows, key=lambda r: (-(r["pct"] if r["pct"] is not None else -1e9), r["label"]))


def sentences(lang_rows, cat_rows, period="this academic year"):
    out = []
    trusted = [r for r in lang_rows if r["pct"] is not None and not r["small"]]
    if trusted:
        top = max(trusted, key=lambda r: r["pct"])
        verb = "increased" if top["pct"] >= 0 else "decreased"
        out.append(f"{top['label']} projects {verb} by {abs(top['pct']):g}% {period}.")
    ctrusted = [r for r in cat_rows if r["pct"] is not None and not r["small"]]
    if ctrusted:
        top = max(ctrusted, key=lambda r: r["pct"])
        if top["pct"] > 0:
            out.append(f"{top['label']} projects are the fastest-growing category, up {top['pct']:g}%.")
    new = [r for r in cat_rows if r["prev"] == 0 and r["cur"] > 0]
    if new:
        out.append("New this year: " + ", ".join(r["label"] for r in new) + ".")
    return out
