"""A small permissioned hash-chained ledger. Pure Python.

Every record links to the hash of the one before it, so changing any past record breaks every hash after it.
This gives tamper evidence and a trusted timestamp order. It is NOT a public blockchain: there is no consensus
network. `anchor` is the seam where a Polygon/Ethereum/Fabric transaction would be recorded in production.
"""
import hashlib
import json

GENESIS = "0" * 64


def canonical(payload):
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)


def block_hash(index, timestamp, kind, payload, prev_hash):
    raw = f"{index}|{timestamp}|{kind}|{canonical(payload)}|{prev_hash}"
    return hashlib.sha256(raw.encode()).hexdigest()


def make_block(index, timestamp, kind, payload, prev_hash):
    ts = timestamp if isinstance(timestamp, str) else timestamp.isoformat()
    return {"index": index, "timestamp": ts, "kind": kind, "payload": payload, "prev_hash": prev_hash,
            "hash": block_hash(index, ts, kind, payload, prev_hash)}


def verify_chain(blocks):
    """blocks oldest first. Returns {'ok', 'checked', 'broken_at', 'reason'}."""
    prev = GENESIS
    for i, b in enumerate(blocks):
        if b["index"] != i:
            return {"ok": False, "checked": i, "broken_at": b["index"], "reason": "block numbers are not in sequence"}
        if b["prev_hash"] != prev:
            return {"ok": False, "checked": i, "broken_at": b["index"], "reason": "link to the previous block is broken"}
        if block_hash(b["index"], b["timestamp"], b["kind"], b["payload"], b["prev_hash"]) != b["hash"]:
            return {"ok": False, "checked": i, "broken_at": b["index"], "reason": "record contents were changed after it was sealed"}
        prev = b["hash"]
    return {"ok": True, "checked": len(blocks), "broken_at": None, "reason": ""}


def fingerprint(text_or_bytes):
    data = text_or_bytes.encode() if isinstance(text_or_bytes, str) else text_or_bytes
    return hashlib.sha256(data).hexdigest()
