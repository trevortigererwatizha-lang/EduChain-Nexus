"""Content-based recommendations from shared interests. Pure Python, no training data needed."""
import math
from collections import Counter


def _vec(tags):
    return Counter(t.strip().lower() for t in tags if t and t.strip())


def similarity(a, b):
    """Cosine similarity between two tag collections, 0-1."""
    va, vb = _vec(a), _vec(b)
    if not va or not vb:
        return 0.0
    dot = sum(va[k] * vb.get(k, 0) for k in va)
    return dot / (math.sqrt(sum(v * v for v in va.values())) * math.sqrt(sum(v * v for v in vb.values())))


def rank(user_tags, items, key=lambda i: i["tags"], boost=lambda i: 0.0, limit=5, exclude=()):
    """items: dicts. Returns [(score 0-100, item, shared tags)] best first; zero-overlap items are dropped."""
    out = []
    mine = {t.lower() for t in user_tags}
    for it in items:
        if it.get("id") in exclude:
            continue
        tags = key(it)
        s = similarity(user_tags, tags)
        if s <= 0:
            continue
        shared = sorted(mine & {t.lower() for t in tags})
        out.append((round(min(1.0, s + boost(it)) * 100), it, shared))
    out.sort(key=lambda r: (-r[0], str(r[1].get("name", r[1].get("title", "")))))
    return out[:limit]


def reason(shared):
    return "Matches your interest in " + ", ".join(shared[:3]) if shared else "Popular right now"
