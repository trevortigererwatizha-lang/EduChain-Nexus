"""Innovation score. Pure Python.

The brief's formula is kept exactly (same nine weights, summing to 1.0). Raw counts cannot be added to each
other fairly, so every input is first scaled to 0-100 against a 'full marks' value (FULL_MARKS) and the
result is therefore also 0-100. Change FULL_MARKS to tune how demanding the score is.
"""
WEIGHTS = {
    "repositories_created": 0.15, "repositories_contributed": 0.10, "project_stars": 0.10,
    "code_quality_score": 0.15, "blockchain_verified_awards": 0.15, "hackathon_participation": 0.10,
    "leadership_score": 0.10, "community_projects": 0.05, "alumni_endorsements": 0.10,
}
FULL_MARKS = {   # the value that earns 100 points for that input
    "repositories_created": 6, "repositories_contributed": 8, "project_stars": 40,
    "code_quality_score": 100, "blockchain_verified_awards": 5, "hackathon_participation": 4,
    "leadership_score": 100, "community_projects": 3, "alumni_endorsements": 5,
}
assert abs(sum(WEIGHTS.values()) - 1.0) < 1e-9


def scale(name, value):
    return round(max(0.0, min(100.0, (value or 0) / FULL_MARKS[name] * 100)), 2)


def innovation_score(inputs):
    """inputs: dict with any of the WEIGHTS keys (missing = 0). Returns (score 0-100, breakdown list)."""
    parts = []
    for k, w in WEIGHTS.items():
        s = scale(k, inputs.get(k, 0))
        parts.append({"key": k, "raw": inputs.get(k, 0) or 0, "scaled": s, "weight": w, "points": round(s * w, 2)})
    return round(sum(p["points"] for p in parts), 1), parts


def collaboration_score(contributed, prs_merged, reviews_or_issues, forks_received):
    """0-100 from how much a student works with others."""
    return round(min(100, contributed * 12 + prs_merged * 10 + reviews_or_issues * 4 + forks_received * 8), 1)


def leadership_score(led_projects, team_sizes, awards, roles):
    """0-100. team_sizes: sizes of teams they led. roles: count of school roles (captain, prefect...)."""
    return round(min(100, led_projects * 15 + sum(min(s, 8) for s in team_sizes) * 3 + awards * 10 + roles * 15), 1)


def code_quality(has_readme, has_tests, commits, issues_closed, issues_total, doc_words):
    """A transparent 0-100 proxy, not a static analyser: documentation, tests, steady commits, issue hygiene."""
    s = 20 if has_readme else 0
    s += 25 if has_tests else 0
    s += min(25, commits * 2.5)
    s += 15 * (issues_closed / issues_total) if issues_total else 7
    s += min(15, doc_words / 20)
    return round(min(100, s), 1)


def tier(score):
    return "Pioneer" if score >= 80 else "Builder" if score >= 60 else "Maker" if score >= 40 else "Explorer" if score >= 20 else "Newcomer"
