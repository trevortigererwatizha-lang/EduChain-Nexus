"""Talent categories and ranking. Pure Python. Rules, not a trained model (see README)."""
CATEGORIES = {
    "Software Engineering": {"web", "api", "javascript", "java", "python", "mobile", "app", "backend", "frontend", "c++"},
    "Artificial Intelligence": {"ai", "ml", "machine learning", "neural", "nlp", "vision", "model"},
    "Cybersecurity": {"security", "crypto", "encryption", "privacy", "pentest"},
    "Data Science": {"data", "analytics", "statistics", "sql", "visualisation", "visualization"},
    "Robotics": {"robotics", "arduino", "iot", "sensor", "embedded", "drone"},
    "UI/UX Design": {"design", "ux", "ui", "figma", "css", "accessibility"},
    "Cloud Computing": {"cloud", "docker", "kubernetes", "devops", "serverless"},
    "Blockchain Development": {"blockchain", "ledger", "smart contract", "ethereum", "polygon"},
}


def category_affinity(tags):
    """{category: number of matching tags} for categories with at least one match."""
    t = {x.strip().lower() for x in tags}
    out = {c: len(t & kw) for c, kw in CATEGORIES.items()}
    return {c: n for c, n in out.items() if n}


def top_category(tags):
    a = category_affinity(tags)
    return max(a, key=lambda c: (a[c], c)) if a else None


def talent_rank(students, category=None):
    """students: dicts {id, name, tags, innovation, activity, collaboration, impact, quality}.
    Ranks by the brief's five signals: code quality, impact, activity, collaboration, innovation."""
    out = []
    for s in students:
        aff = category_affinity(s["tags"])
        if category and category not in aff:
            continue
        fit = aff.get(category, sum(aff.values())) if aff else 0
        score = (s["quality"] * .25 + s["impact"] * .20 + s["activity"] * .15 + s["collaboration"] * .15 + s["innovation"] * .25)
        out.append({**s, "talent": round(score + min(10, fit * 2.5), 1), "category": category or top_category(s["tags"])})
    return sorted(out, key=lambda r: (-r["talent"], r["name"]))
