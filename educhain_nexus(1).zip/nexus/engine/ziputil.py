"""Safe handling of uploaded application zips. Pure Python, nothing is ever extracted to disk or executed.

Threats handled: zip-slip paths (../, absolute, drive letters, backslashes), symlinks, encrypted members,
zip bombs (member count, total size, per-file size, compression ratio, lying size headers), and non-zip uploads.
"""
import io
import posixpath
import stat
import zipfile

MAX_UPLOAD = 25 * 1024 * 1024          # compressed bytes accepted
MAX_FILES = 2000
MAX_TOTAL = 200 * 1024 * 1024          # uncompressed bytes in all
MAX_MEMBER = 20 * 1024 * 1024
MAX_RATIO = 200                         # uncompressed / compressed for the whole archive
MAX_PREVIEW = 200 * 1024
MAX_EDIT = 512 * 1024
TEXT_EXT = {".py", ".js", ".ts", ".jsx", ".tsx", ".java", ".c", ".h", ".cpp", ".hpp", ".cs", ".go", ".rs", ".rb", ".php", ".kt", ".swift", ".sql",
            ".html", ".htm", ".css", ".scss", ".json", ".yml", ".yaml", ".toml", ".ini", ".cfg", ".xml", ".md", ".txt", ".csv", ".sh", ".bat",
            ".gradle", ".ino", ".r", ".ipynb", ".env.example", ".gitignore", ".dockerfile", ".lock"}
TEXT_NAMES = {"readme", "license", "dockerfile", "makefile", "procfile", "requirements.txt", ".gitignore"}


class ZipRejected(ValueError):
    """The zip cannot be accepted. The message is safe to show to the user."""


def safe_name(name):
    """Return the cleaned member path or raise ZipRejected."""
    if not name or "\x00" in name:
        raise ZipRejected("The zip contains a file with an empty or invalid name.")
    if "\\" in name or name.startswith("/") or (len(name) > 1 and name[1] == ":"):
        raise ZipRejected(f"The zip contains an unsafe path: {name!r}. Re-create it with your zip tool using relative paths.")
    parts = name.split("/")
    if any(p == ".." for p in parts):
        raise ZipRejected(f"The zip contains a path that climbs out of its folder: {name!r}.")
    clean = posixpath.normpath(name) + ("/" if name.endswith("/") else "")
    if len(clean) > 240:
        raise ZipRejected("A path inside the zip is longer than 240 characters.")
    return clean


def _ext(name):
    base = posixpath.basename(name).lower()
    if base in TEXT_NAMES:
        return base
    dot = base.rfind(".")
    return base[dot:] if dot > 0 else ""


def looks_text(name, sample=b""):
    e = _ext(name)
    if e in TEXT_EXT or e in TEXT_NAMES:
        return b"\x00" not in sample
    return False


def inspect(data):
    """Validate `data` (bytes of a zip) and describe it. Raises ZipRejected."""
    if len(data) > MAX_UPLOAD:
        raise ZipRejected(f"The file is larger than {MAX_UPLOAD // (1024 * 1024)} MB. Remove build outputs or dependency folders (node_modules, venv) and try again.")
    if not data[:4] in (b"PK\x03\x04", b"PK\x05\x06"):
        raise ZipRejected("That is not a .zip file.")
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
        infos = zf.infolist()
    except (zipfile.BadZipFile, NotImplementedError, OSError, ValueError, EOFError):
        raise ZipRejected("That zip file is damaged or uses an unsupported format.") from None
    if not infos:
        raise ZipRejected("The zip is empty.")
    if len(infos) > MAX_FILES:
        raise ZipRejected(f"The zip has more than {MAX_FILES:,} files.")
    files, total, seen = [], 0, set()
    for i in infos:
        name = safe_name(i.filename)
        if name in seen:
            raise ZipRejected(f"The zip lists {name!r} twice.")
        seen.add(name)
        if i.flag_bits & 0x1:
            raise ZipRejected("The zip is password protected. Upload it without a password.")
        mode = (i.external_attr >> 16) & 0xFFFF
        if mode and stat.S_ISLNK(mode):
            raise ZipRejected(f"The zip contains a symbolic link ({name!r}), which is not allowed.")
        if i.file_size > MAX_MEMBER:
            raise ZipRejected(f"{name!r} is larger than {MAX_MEMBER // (1024 * 1024)} MB uncompressed.")
        total += i.file_size
        files.append({"name": name, "size": i.file_size, "dir": name.endswith("/")})
    if total > MAX_TOTAL:
        raise ZipRejected(f"The zip expands to more than {MAX_TOTAL // (1024 * 1024)} MB.")
    if total / max(1, len(data)) > MAX_RATIO:
        raise ZipRejected("The zip is compressed suspiciously hard and was refused as a precaution.")
    for f in files:
        f["text"] = (not f["dir"]) and looks_text(f["name"])
    files.sort(key=lambda f: (f["name"].rstrip("/").split("/")[:-1] if not f["dir"] else f["name"].rstrip("/").split("/"), f["dir"] is False, f["name"]))
    return {"files": files, "count": sum(not f["dir"] for f in files), "total": total}


def read_member(data, name, limit=MAX_PREVIEW):
    """Bytes of one member, never reading more than limit+1 bytes. Returns (bytes, truncated)."""
    name = safe_name(name)
    with zipfile.ZipFile(io.BytesIO(data)) as zf:
        try:
            info = zf.getinfo(name)
        except KeyError:
            raise ZipRejected("That file is not in the zip.") from None
        if name.endswith("/"):
            raise ZipRejected("That is a folder.")
        with zf.open(info) as fh:
            chunk = fh.read(limit + 1)
    return chunk[:limit], len(chunk) > limit


def preview_text(data, name):
    """Decoded text for display or None when the file is binary, too big, or not UTF-8."""
    if not looks_text(name):
        return None
    chunk, truncated = read_member(data, name)
    if b"\x00" in chunk:
        return None
    try:
        return chunk.decode("utf-8") + ("\n\n[Preview cut off. Download the app to see the rest.]" if truncated else "")
    except UnicodeDecodeError:
        return None


def replace_member(data, name, new_bytes):
    """A new zip identical to `data` except `name` now holds `new_bytes`. Original is untouched."""
    name = safe_name(name)
    if len(new_bytes) > MAX_EDIT:
        raise ZipRejected(f"Edits are limited to {MAX_EDIT // 1024} KB per file. Upload a new zip for larger changes.")
    if not looks_text(name):
        raise ZipRejected("Only text files can be edited here.")
    inspect(data)
    out = io.BytesIO()
    found = False
    with zipfile.ZipFile(io.BytesIO(data)) as zin, zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zout:
        for info in zin.infolist():
            if info.filename == name:
                found = True
                zi = zipfile.ZipInfo(info.filename, date_time=info.date_time)
                zi.compress_type, zi.external_attr = zipfile.ZIP_DEFLATED, info.external_attr
                zout.writestr(zi, new_bytes)
            else:
                zi = zipfile.ZipInfo(info.filename, date_time=info.date_time)
                zi.compress_type, zi.external_attr = zipfile.ZIP_DEFLATED, info.external_attr
                with zin.open(info) as fh:
                    zout.writestr(zi, b"" if info.is_dir() else fh.read(MAX_MEMBER + 1)[:MAX_MEMBER])
    if not found:
        raise ZipRejected("That file is not in the zip.")
    result = out.getvalue()
    inspect(result)
    return result


def top_level(files):
    """A short description of the main folder or entry files, for display."""
    names = [f["name"] for f in files if not f["dir"]]
    roots = {n.split("/")[0] for n in names if "/" in n}
    if len(roots) == 1 and all("/" in n for n in names):
        return roots.pop() + "/"
    return ""


def depth_rows(files):
    """Flat rows for a simple indented file tree."""
    rows = []
    for f in files:
        parts = f["name"].rstrip("/").split("/")
        rows.append({**f, "depth": len(parts) - 1, "base": parts[-1] + ("/" if f["dir"] else "")})
    return rows
