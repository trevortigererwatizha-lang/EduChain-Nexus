from django.contrib import admin

from . import models as m

for model in (m.School, m.Profile, m.AlumniProfile, m.Project, m.Award, m.Endorsement, m.Mentorship, m.Event, m.Listing, m.AppPackage):
    admin.site.register(model)


class ReadOnly(admin.ModelAdmin):
    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(m.LedgerBlock)
class LedgerAdmin(ReadOnly):
    list_display = ("index", "kind", "timestamp", "hash")


@admin.register(m.ImportJob)
class ImportAdmin(ReadOnly):
    list_display = ("created_at", "kind", "filename", "status", "user")
    exclude = ("raw",)


@admin.register(m.AuditLog)
class AuditAdmin(ReadOnly):
    list_display = ("created_at", "user", "action", "ip_address")


@admin.register(m.AppVersion)
class AppVersionAdmin(ReadOnly):
    list_display = ("package", "number", "kind", "size", "uploaded_by", "created")
    exclude = ("manifest",)
