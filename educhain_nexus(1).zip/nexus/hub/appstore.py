"""Saving, versioning and editing uploaded app zips. Validation is in engine.ziputil."""
import hashlib

from django.core.files.base import ContentFile
from django.db import transaction

from engine import ziputil
from .models import AppPackage, AppVersion

MAX_PACKAGES_PER_USER = 20
MAX_VERSIONS = 40
MAX_STORAGE_PER_USER = 500 * 1024 * 1024


class Refused(ValueError):
    """Message is safe to show to the user."""


def can_edit(user, pkg):
    return user.is_authenticated and user.is_active and (user == pkg.owner or user.is_data_admin or pkg.open_edit)


def can_manage(user, pkg):
    return user.is_authenticated and (user == pkg.owner or user.is_data_admin)


def read_bytes(version):
    with version.file.open("rb") as fh:
        return fh.read()


def _store(pkg, user, data, kind, note):
    try:
        report = ziputil.inspect(data)
    except ziputil.ZipRejected as e:
        raise Refused(str(e)) from None
    last = pkg.versions.order_by("-number").first()
    if last and last.number >= MAX_VERSIONS:
        raise Refused(f"This app already has {MAX_VERSIONS} versions. The owner can delete old ones by removing and re-uploading it.")
    used = sum(v.size for v in AppVersion.objects.filter(package__owner=pkg.owner))
    if used + len(data) > MAX_STORAGE_PER_USER:
        raise Refused("The owner's storage allowance (500 MB) is full.")
    v = AppVersion(package=pkg, number=(last.number + 1) if last else 1, size=len(data), sha256=hashlib.sha256(data).hexdigest(),
                   file_count=report["count"], total_size=report["total"], manifest=report["files"], kind=kind, note=note[:200], uploaded_by=user)
    v.file.save("app.zip", ContentFile(data), save=False)
    v.save()
    pkg.save(update_fields=["updated"])
    return v


@transaction.atomic
def create_package(owner, title, description, tags, data, project=None, note="First upload"):
    if AppPackage.objects.filter(owner=owner).count() >= MAX_PACKAGES_PER_USER:
        raise Refused(f"You can keep up to {MAX_PACKAGES_PER_USER} apps. Remove one first.")
    pkg = AppPackage.objects.create(owner=owner, title=title, description=description, tags=tags, project=project)
    try:
        _store(pkg, owner, data, "upload", note)
    except Refused:
        transaction.set_rollback(True)
        raise
    return pkg


@transaction.atomic
def add_version(pkg, user, data, note="", kind="upload"):
    if not can_edit(user, pkg):
        raise Refused("You can view and download this app, but the owner has not allowed edits.")
    return _store(pkg, user, data, kind, note or "New upload")


@transaction.atomic
def edit_file(pkg, user, path, text, base_sha, note=""):
    """Save an edited text file as a new version. Refuses if somebody changed the same file meanwhile."""
    if not can_edit(user, pkg):
        raise Refused("You can view and download this app, but the owner has not allowed edits.")
    latest = pkg.latest
    data = read_bytes(latest)
    try:
        current, _ = ziputil.read_member(data, path, ziputil.MAX_EDIT)
        if hashlib.sha256(current).hexdigest() != base_sha:
            raise Refused("Someone saved a change to this file while you were editing. Reload the file and make your edit again.")
        new = ziputil.replace_member(data, path, text.replace("\r\n", "\n").encode("utf-8"))
    except ziputil.ZipRejected as e:
        raise Refused(str(e)) from None
    return _store(pkg, user, new, "edit", note or f"Edited {path}")


@transaction.atomic
def restore(pkg, user, number):
    if not can_manage(user, pkg):
        raise Refused("Only the owner can restore an older version.")
    old = pkg.versions.filter(number=number).first()
    if not old:
        raise Refused("That version does not exist.")
    return _store(pkg, user, read_bytes(old), "restore", f"Restored version {number}")


def delete_package(pkg):
    for v in pkg.versions.all():
        v.file.delete(save=False)
    pkg.delete()


def download_name(pkg, v):
    base = "".join(c if c.isalnum() or c in "-_" else "-" for c in pkg.title.lower())[:50].strip("-") or "app"
    return f"{base}-v{v.number}.zip"
