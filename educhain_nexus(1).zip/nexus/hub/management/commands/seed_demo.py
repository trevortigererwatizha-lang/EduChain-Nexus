"""Synthetic demo data (no real people): python manage.py seed_demo [--reset]"""
import random
from datetime import date, timedelta

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand
from django.db import transaction

import io
import zipfile

from hub import appstore, services
from hub.models import (Activity, AlumniProfile, Award, Endorsement, Event, Listing, Mentorship, Profile, Project, School, LedgerBlock)

PASSWORD = "nexus-demo"
SCHOOLS = [("HRE01", "Harare Central High", "Harare"), ("BYO02", "Bulawayo Science Academy", "Bulawayo"),
           ("MUT03", "Mutare Ridge College", "Mutare"), ("GWE04", "Gweru Tech School", "Gweru")]
FIRST = "Tariro Farai Chipo Tendai Nyasha Rudo Tafara Kuda Anesu Vimbai Takudzwa Rufaro Tinashe Ruvimbo Simba Nomsa Thabo Lerato".split()
LAST = "Moyo Ncube Dube Sibanda Phiri Banda Chuma Zulu Mutasa Ndlovu Khumalo Tembo Mlambo Gumbo Jere Mapfumo".split()
IDEAS = [("Crop Doctor", "Machine Learning", "Python", ["ai", "vision", "agriculture"]), ("Bus Tracker", "Web Application", "JavaScript", ["web", "maps", "api"]),
         ("Solar Monitor", "IoT", "C++", ["iot", "sensor", "energy"]), ("Exam Planner", "Mobile Application", "Java", ["mobile", "education"]),
         ("Lab Notebook", "Science", "Python", ["data", "science"]), ("Rover One", "Robotics", "C++", ["robotics", "arduino"]),
         ("Safe Vote", "Blockchain", "JavaScript", ["blockchain", "ledger", "security"]), ("Water Watch", "IoT", "Python", ["iot", "data", "sensor"]),
         ("Study Buddy", "AI", "Python", ["ai", "nlp", "education"]), ("Campus Map", "Web Application", "HTML", ["web", "design", "ux"]),
         ("Bridge Loads", "Engineering", "Python", ["engineering", "data"]), ("Pulse Paper", "Research Paper", "Python", ["research", "statistics"]),
         ("Cloud Notes", "Web Application", "JavaScript", ["cloud", "docker", "web"]), ("Gate Lock", "Engineering", "C++", ["security", "embedded"])]
SKILLS = ["Python", "JavaScript", "SQL", "C++", "Java", "HTML", "CSS", "Git"]
INTERESTS = ["ai", "robotics", "web", "data", "security", "blockchain", "iot", "design", "cloud", "mobile"]
README = "# {t}\n\nA {c} project built by a student team.\n\n## Why\nSolves a real problem we saw at school.\n\n## Run it\nInstall the dependencies and start the app.\n\n## Tests\nSee the tests folder."


class Command(BaseCommand):
    help = "Seed synthetic demo data"

    def add_arguments(self, p):
        p.add_argument("--reset", action="store_true")

    @transaction.atomic
    def handle(self, *a, **o):
        U = get_user_model()
        if o["reset"]:
            LedgerBlock.objects.all().delete()
            for M in (Event, Listing, Mentorship, Endorsement, Award, Activity, Project, AlumniProfile, Profile, School):
                M.objects.all().delete()
            U.objects.exclude(is_superuser=True).delete()
        elif School.objects.exists():
            self.stdout.write("Data already exists. Use --reset to rebuild."); return
        rnd = random.Random(7)
        today = date.today()
        admin, _ = U.objects.get_or_create(username="admin", defaults={"role": "admin", "is_staff": True, "is_superuser": True})
        admin.set_password(PASSWORD); admin.save()
        schools = [School.objects.create(code=c, name=n, city=ci, country="Zimbabwe", motto="Building future innovators") for c, n, ci in SCHOOLS]
        students = []
        for si, s in enumerate(schools):
            for i in range(10):
                name = f"{rnd.choice(FIRST)} {rnd.choice(LAST)}"
                u = U.objects.create(username=f"{name.split()[0].lower()}.{s.code.lower()}{i}", first_name=name.split()[0], last_name=name.split()[1], role="student")
                u.set_password(PASSWORD); u.save()
                pr = Profile.objects.create(user=u, school=s, form=f"Form {rnd.randint(3, 6)}", skills=rnd.sample(SKILLS, 3),
                                            interests=rnd.sample(INTERESTS, 2), leadership_roles=rnd.choice([0, 0, 0, 1, 2]),
                                            bio="Curious about building things that help people.")
                students.append((u, pr, 0.4 + 0.12 * (3 - si) + rnd.random() * .4))      # activity level
        alumni = []
        for i in range(8):
            s = schools[i % 4]
            name = f"{rnd.choice(FIRST)} {rnd.choice(LAST)}"
            u = U.objects.create(username=f"alum.{i}", first_name=name.split()[0], last_name=name.split()[1], role="alumni")
            u.set_password(PASSWORD); u.save()
            Profile.objects.create(user=u, school=s, interests=rnd.sample(INTERESTS, 2))
            AlumniProfile.objects.create(user=u, graduation_year=2014 + i, university=rnd.choice(["University of Cape Town", "University of Zimbabwe", "Wits", "NUST"]),
                                         degree=rnd.choice(["BSc Computer Science", "BEng Electronic", "BSc Data Science"]), employer=rnd.choice(["Acme Cloud", "Delta Labs", "Sunrise Energy"]),
                                         position="Engineer", industry=rnd.choice(["Cloud", "Energy", "Fintech", "AI"]), mentoring=i % 3 != 2)
            alumni.append(u)
        recs = []
        for u, pr, lvl in students:
            if rnd.random() > min(.95, lvl + .2):
                continue
            for k in range(1 + int(lvl * 2.2)):
                t, cat, lang, tags = rnd.choice(IDEAS)
                created = today - timedelta(days=rnd.randint(10, 560))
                p = Project.objects.create(slug=f"{t.lower().replace(' ', '-')}-{u.username}".replace(".", "-")[:56] + str(k), title=t, owner=u, category=cat,
                                           primary_language=lang, description=f"{t}: a student {cat.lower()} project.", tags=tags, created=created,
                                           readme=README.format(t=t, c=cat) if rnd.random() < .8 else "", has_tests=rnd.random() < .45,
                                           base_stars=int(rnd.random() * lvl * 14), views=int(rnd.random() * 400 * lvl), downloads=int(rnd.random() * 60),
                                           community=rnd.random() < .25)
                mates = rnd.sample([x[0] for x in students if x[0] != u], rnd.choice([0, 0, 1, 2]))
                p.collaborators.set(mates)
                for _ in range(int(3 + lvl * 14)):
                    who = rnd.choice([u, u, *mates])
                    kind = rnd.choices(["commit", "issue", "pull_request"], [8, 2, 1])[0]
                    d = min(today, created + timedelta(days=rnd.randint(0, 540)))
                    recs.append(Activity(project=p, author=who, date=d, kind=kind, message=f"{kind.replace('_', ' ')}: update {rnd.choice(['model', 'ui', 'docs', 'tests', 'api'])}", done=rnd.random() < .7))
                services.anchor_project(p)
        Activity.objects.bulk_create(recs, batch_size=1000)
        for u, pr, lvl in students:
            for _ in range(int(rnd.random() * lvl * 3)):
                a = Award.objects.create(user=u, title=rnd.choice(["Regional Coding Challenge", "Science Fair Gold", "Innovation Award", "Robotics Cup Finalist", "Leadership Award"]),
                                         award_type=rnd.choice(["competition", "innovation", "coding", "leadership", "examination"]), issuer="Ministry of Education",
                                         date=today - timedelta(days=rnd.randint(20, 500)))
                if rnd.random() < .85:
                    services.anchor_award(a)
            if rnd.random() < lvl / 1.3:
                e = Endorsement.objects.create(alumnus=rnd.choice(alumni), student=u, note="Strong problem solver.")
                services.anchor_endorsement(e)
        for u, pr, lvl in students[:12]:
            Mentorship.objects.get_or_create(mentor=rnd.choice(alumni), student=u, defaults={"message": "Would love guidance on my project.", "status": "active"})
        evs = [("Inter-school Hackathon", "Innovation", 30), ("Science Fair", "Innovation", 50), ("Open Day", "University", 15), ("Alumni Networking Evening", "Alumni", 24),
               ("Athletics Championship", "Sports", 40), ("Mock Examinations", "Academic", 9), ("Robotics Competition", "Innovation", 70), ("Scholarship Deadline", "University", 33),
               ("Parent Consultation Day", "Academic", 18), ("Career Day", "Alumni", 60), ("Coding Competition", "Innovation", 85), ("Swimming Gala", "Sports", 45)]
        for title, cat, off in evs:
            e = Event.objects.create(title=title, category=cat, start_date=today + timedelta(days=off - 10), school=rnd.choice([None, *schools]),
                                     location=rnd.choice(["Main hall", "Sports field", "Online"]), description=f"{title} for students, staff and alumni.")
            e.attendees.set([x[0] for x in rnd.sample(students, 8)] if cat == "Innovation" else [])
        for p in rnd.sample(list(Project.objects.all()), 6):
            Listing.objects.create(slug=f"{p.slug}-listing"[:60], title=p.title, owner=p.owner, project=p, license="MIT", created=today - timedelta(days=rnd.randint(1, 120)),
                                   category=rnd.choice(["Software", "Mobile Apps", "Robotics", "Games", "Websites", "Research Results"]), description=f"{p.description} Free for schools.")
        # two demo apps (small zips) and two registrations waiting for approval
        for (u, pr, lvl), title in zip(students[:2], ["Quiz Maker", "Timetable Helper"]):
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
                slug = title.lower().replace(" ", "_")
                z.writestr(f"{slug}/README.md", f"# {title}\n\nA small demo app. Open main.py to see how it works.\n")
                z.writestr(f"{slug}/main.py", f'def main():\n    print("{title} is running")\n\n\nif __name__ == "__main__":\n    main()\n')
            appstore.create_package(u, title, f"{title}: a small demo app you can browse, edit and download.", ["python", "demo"], buf.getvalue())
        for name, role in (("Rudo Chuma", "student"), ("Kuda Phiri", "alumni")):
            u = U.objects.create(username=name.split()[0].lower() + ".new", first_name=name.split()[0], last_name=name.split()[1], role=role, email=f"{name.split()[0].lower()}@example.org",
                                 status="pending", is_active=False, reg_note="Please add me, I am in Form 4.")
            u.set_password(PASSWORD); u.save()
            Profile.objects.create(user=u, school=schools[0])
            if role == "alumni":
                AlumniProfile.objects.create(user=u, graduation_year=2022)
        self.stdout.write(self.style.SUCCESS(f"Seeded {len(schools)} schools, {len(students)} students, {Project.objects.count()} projects, "
                                             f"{LedgerBlock.objects.count()} ledger records. Sign in as admin or any student/alumni username with password '{PASSWORD}'."))
