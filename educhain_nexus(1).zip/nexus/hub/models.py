from django.conf import settings
from django.db import models
from django.utils import timezone

from engine import csvio

U = settings.AUTH_USER_MODEL


def cat_choices(values):
    return [(v, v) for v in values]


class School(models.Model):
    code = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=120)
    city = models.CharField(max_length=80, blank=True)
    country = models.CharField(max_length=80, blank=True)
    motto = models.CharField(max_length=160, blank=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name


class Profile(models.Model):
    """Student, teacher or alumni profile shown in the portfolio and the directory."""
    user = models.OneToOneField(U, on_delete=models.CASCADE, related_name="profile")
    school = models.ForeignKey(School, null=True, blank=True, on_delete=models.SET_NULL, related_name="profiles")
    form = models.CharField(max_length=20, blank=True)
    bio = models.CharField(max_length=300, blank=True)
    skills = models.JSONField(default=list, blank=True)
    interests = models.JSONField(default=list, blank=True)
    leadership_roles = models.PositiveSmallIntegerField(default=0, help_text="school roles such as captain or prefect")
    followers = models.ManyToManyField(U, blank=True, related_name="following")

    def __str__(self):
        return self.user.display

    @property
    def tags(self):
        return [*self.skills, *self.interests]


class AlumniProfile(models.Model):
    user = models.OneToOneField(U, on_delete=models.CASCADE, related_name="alumni")
    graduation_year = models.PositiveSmallIntegerField()
    university = models.CharField(max_length=120, blank=True)
    degree = models.CharField(max_length=120, blank=True)
    employer = models.CharField(max_length=120, blank=True)
    position = models.CharField(max_length=120, blank=True)
    industry = models.CharField(max_length=80, blank=True)
    mentoring = models.BooleanField(default=False)

    class Meta:
        ordering = ["-graduation_year"]


class Project(models.Model):
    slug = models.SlugField(max_length=60, unique=True)
    title = models.CharField(max_length=120)
    owner = models.ForeignKey(U, on_delete=models.CASCADE, related_name="projects")
    category = models.CharField(max_length=30, choices=cat_choices(csvio.CATEGORIES))
    primary_language = models.CharField(max_length=30)
    description = models.CharField(max_length=600, blank=True)
    readme = models.TextField(blank=True)
    tags = models.JSONField(default=list, blank=True)
    created = models.DateField(default=timezone.localdate)
    forked_from = models.ForeignKey("self", null=True, blank=True, on_delete=models.SET_NULL, related_name="forks")
    base_stars = models.PositiveIntegerField(default=0, help_text="stars carried over from an import")
    has_tests = models.BooleanField(default=False)
    collaborators = models.ManyToManyField(U, blank=True, related_name="contributing_to")
    starred_by = models.ManyToManyField(U, blank=True, related_name="starred")
    views = models.PositiveIntegerField(default=0)
    downloads = models.PositiveIntegerField(default=0)
    community = models.BooleanField(default=False, help_text="serves the school or wider community")
    ledger_hash = models.CharField(max_length=64, blank=True)

    class Meta:
        ordering = ["-created"]

    def __str__(self):
        return self.title

    @property
    def stars(self):
        return self.base_stars + self.starred_by.count()


class Activity(models.Model):
    """A commit, issue or pull request. Drives the contribution calendar and the score."""
    KINDS = [("commit", "Commit"), ("issue", "Issue"), ("pull_request", "Pull request")]
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name="activity")
    author = models.ForeignKey(U, on_delete=models.CASCADE, related_name="activity")
    date = models.DateField()
    kind = models.CharField(max_length=14, choices=KINDS)
    message = models.CharField(max_length=160)
    done = models.BooleanField(default=True, help_text="issue closed or pull request merged")

    class Meta:
        ordering = ["-date", "-id"]
        indexes = [models.Index(fields=["author", "date"]), models.Index(fields=["project", "kind"])]


class Award(models.Model):
    user = models.ForeignKey(U, on_delete=models.CASCADE, related_name="awards")
    title = models.CharField(max_length=120)
    award_type = models.CharField(max_length=20, choices=cat_choices(csvio.AWARD_TYPES))
    issuer = models.CharField(max_length=120)
    date = models.DateField()
    ledger_hash = models.CharField(max_length=64, blank=True)

    class Meta:
        ordering = ["-date"]


class Endorsement(models.Model):
    alumnus = models.ForeignKey(U, on_delete=models.CASCADE, related_name="endorsements_given")
    student = models.ForeignKey(U, on_delete=models.CASCADE, related_name="endorsements")
    note = models.CharField(max_length=200, blank=True)
    created = models.DateField(default=timezone.localdate)
    ledger_hash = models.CharField(max_length=64, blank=True)

    class Meta:
        unique_together = [("alumnus", "student")]


class Mentorship(models.Model):
    mentor = models.ForeignKey(U, on_delete=models.CASCADE, related_name="mentees_requests")
    student = models.ForeignKey(U, on_delete=models.CASCADE, related_name="mentor_requests")
    message = models.CharField(max_length=300, blank=True)
    status = models.CharField(max_length=10, default="requested", choices=[("requested", "Requested"), ("active", "Active"), ("closed", "Closed")])
    created = models.DateField(default=timezone.localdate)

    class Meta:
        unique_together = [("mentor", "student")]


class Event(models.Model):
    title = models.CharField(max_length=120)
    category = models.CharField(max_length=20, choices=cat_choices(csvio.EVENT_CATEGORIES))
    start_date = models.DateField()
    end_date = models.DateField(null=True, blank=True)
    location = models.CharField(max_length=120, blank=True)
    school = models.ForeignKey(School, null=True, blank=True, on_delete=models.SET_NULL, related_name="events")
    description = models.CharField(max_length=400, blank=True)
    attendees = models.ManyToManyField(U, blank=True, related_name="events_registered")

    class Meta:
        ordering = ["start_date", "title"]


class Listing(models.Model):
    slug = models.SlugField(max_length=60, unique=True)
    title = models.CharField(max_length=120)
    owner = models.ForeignKey(U, on_delete=models.CASCADE, related_name="listings")
    category = models.CharField(max_length=20, choices=cat_choices(csvio.LISTING_CATEGORIES))
    description = models.CharField(max_length=600, blank=True)
    license = models.CharField(max_length=60, blank=True)
    project = models.ForeignKey(Project, null=True, blank=True, on_delete=models.SET_NULL, related_name="listings")
    downloads = models.PositiveIntegerField(default=0)
    created = models.DateField(default=timezone.localdate)

    class Meta:
        ordering = ["-created"]


class Interest(models.Model):
    """Investor or licensing interest in a listing."""
    listing = models.ForeignKey(Listing, on_delete=models.CASCADE, related_name="interests")
    user = models.ForeignKey(U, on_delete=models.CASCADE, related_name="+")
    message = models.CharField(max_length=400, blank=True)
    created = models.DateTimeField(auto_now_add=True)


class LedgerBlock(models.Model):
    index = models.PositiveIntegerField(unique=True)
    timestamp = models.CharField(max_length=40)
    kind = models.CharField(max_length=20)
    payload = models.JSONField()
    prev_hash = models.CharField(max_length=64)
    hash = models.CharField(max_length=64, unique=True)

    class Meta:
        ordering = ["index"]

    def as_dict(self):
        return {"index": self.index, "timestamp": self.timestamp, "kind": self.kind, "payload": self.payload,
                "prev_hash": self.prev_hash, "hash": self.hash}


class ImportJob(models.Model):
    class Status(models.TextChoices):
        PREVIEWED = "previewed", "Validated, awaiting confirmation"
        COMMITTED = "committed", "Imported"
        FAILED = "failed", "Not imported"

    kind = models.CharField(max_length=12)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.PREVIEWED)
    filename = models.CharField(max_length=200)
    sha256 = models.CharField(max_length=64)
    raw = models.TextField(blank=True)
    user = models.ForeignKey(U, null=True, on_delete=models.SET_NULL, related_name="+")
    rows_total = models.PositiveIntegerField(default=0)
    rows_created = models.PositiveIntegerField(default=0)
    rows_updated = models.PositiveIntegerField(default=0)
    errors = models.JSONField(default=list, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]


class AuditLog(models.Model):
    user = models.ForeignKey(U, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    action = models.CharField(max_length=60, db_index=True)
    detail = models.JSONField(default=dict, blank=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]


def audit(user, action, detail=None, request=None):
    ip = None
    if request is not None:
        fwd = request.META.get("HTTP_X_FORWARDED_FOR", "")
        ip = (fwd.split(",")[0].strip() if fwd else request.META.get("REMOTE_ADDR")) or None
    return AuditLog.objects.create(user=user if getattr(user, "is_authenticated", False) else None,
                                   action=action, detail=detail or {}, ip_address=ip)


def app_upload_path(instance, filename):
    """Storage name is generated, never taken from the uploader."""
    import uuid
    return f"apps/u{instance.package.owner_id}/{uuid.uuid4().hex}.zip"


class AppPackage(models.Model):
    """An application a member uploaded as a zip. Every change is kept as a numbered version."""
    owner = models.ForeignKey(U, on_delete=models.CASCADE, related_name="app_packages")
    title = models.CharField(max_length=120)
    description = models.CharField(max_length=600, blank=True)
    tags = models.JSONField(default=list, blank=True)
    project = models.ForeignKey(Project, null=True, blank=True, on_delete=models.SET_NULL, related_name="apps")
    open_edit = models.BooleanField(default=True, help_text="other signed-in members may save edits as new versions")
    downloads = models.PositiveIntegerField(default=0)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-updated"]

    def __str__(self):
        return self.title

    @property
    def latest(self):
        return self.versions.order_by("-number").first()


class AppVersion(models.Model):
    package = models.ForeignKey(AppPackage, on_delete=models.CASCADE, related_name="versions")
    number = models.PositiveIntegerField()
    file = models.FileField(upload_to=app_upload_path, max_length=200)
    size = models.PositiveBigIntegerField()
    sha256 = models.CharField(max_length=64)
    file_count = models.PositiveIntegerField(default=0)
    total_size = models.PositiveBigIntegerField(default=0)
    manifest = models.JSONField(default=list, blank=True)
    kind = models.CharField(max_length=10, default="upload", choices=[("upload", "Upload"), ("edit", "Edit"), ("restore", "Restore")])
    note = models.CharField(max_length=200, blank=True)
    uploaded_by = models.ForeignKey(U, null=True, on_delete=models.SET_NULL, related_name="+")
    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-number"]
        unique_together = [("package", "number")]
