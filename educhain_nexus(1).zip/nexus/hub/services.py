"""Database -> engine glue. All scoring maths lives in engine/."""
from collections import Counter, defaultdict
from datetime import date, timedelta

from django.db import transaction
from django.db.models import Count
from django.utils import timezone

from engine import insights, ledger, recommend, scoring, talent
from .models import (Activity, AlumniProfile, Award, Endorsement, Event, LedgerBlock, Listing, Profile, Project, School)


# ----------------------------------------------------------------------------- ledger
@transaction.atomic
def anchor(kind, payload):
    """Seal a record into the ledger and return its hash."""
    last = LedgerBlock.objects.order_by("-index").first()
    index, prev = (last.index + 1, last.hash) if last else (0, ledger.GENESIS)
    b = ledger.make_block(index, timezone.now().replace(microsecond=0), kind, payload, prev)
    LedgerBlock.objects.create(**b)
    return b["hash"]


def anchor_award(a):
    a.ledger_hash = anchor("award", {"award": a.id, "holder": a.user.username, "title": a.title, "type": a.award_type,
                                     "issuer": a.issuer, "date": a.date.isoformat()})
    a.save(update_fields=["ledger_hash"])


def anchor_project(p):
    p.ledger_hash = anchor("ownership", {"project": p.slug, "owner": p.owner.username, "title": p.title,
                                         "content_sha256": ledger.fingerprint(f"{p.title}\n{p.description}\n{p.readme}"),
                                         "first_published": p.created.isoformat()})
    p.save(update_fields=["ledger_hash"])


def anchor_endorsement(e):
    e.ledger_hash = anchor("endorsement", {"alumnus": e.alumnus.username, "student": e.student.username,
                                           "note": e.note, "date": e.created.isoformat()})
    e.save(update_fields=["ledger_hash"])


def verify_ledger():
    return ledger.verify_chain([b.as_dict() for b in LedgerBlock.objects.all()])


# ----------------------------------------------------------------------------- per-student metrics
def all_metrics(today=None):
    """{user_id: metrics} for every student profile, using a fixed number of queries."""
    today = today or timezone.localdate()
    profiles = list(Profile.objects.filter(user__role="student", user__is_active=True).select_related("user", "school"))
    ids = [p.user_id for p in profiles]
    projects = list(Project.objects.annotate(nstars=Count("starred_by", distinct=True), ncollab=Count("collaborators", distinct=True)))
    by_proj = {p.id: p for p in projects}
    act = defaultdict(Counter)
    closed, total_issues, merged, issues_by, authors = Counter(), Counter(), Counter(), Counter(), defaultdict(set)
    recent = Counter()
    cutoff = today - timedelta(days=90)
    for a in Activity.objects.values("project_id", "author_id", "kind", "done", "date"):
        act[a["project_id"]][a["kind"]] += 1
        authors[a["project_id"]].add(a["author_id"])
        if a["kind"] == "issue":
            total_issues[a["project_id"]] += 1
            closed[a["project_id"]] += a["done"]
            issues_by[a["author_id"]] += 1
        if a["kind"] == "pull_request" and a["done"]:
            merged[a["author_id"]] += 1
        if a["kind"] == "commit" and a["date"] >= cutoff:
            recent[a["author_id"]] += 1
    collab = defaultdict(set)
    for pid, uid in Project.collaborators.through.objects.values_list("project_id", "user_id"):
        collab[pid].add(uid)
    quality = {p.id: scoring.code_quality(bool(p.readme), p.has_tests, act[p.id]["commit"], closed[p.id], total_issues[p.id], len(p.readme.split())) for p in projects}
    owned, contributed = defaultdict(list), defaultdict(set)
    forks = Counter()
    for p in projects:
        owned[p.owner_id].append(p)
        if p.forked_from_id and p.forked_from_id in by_proj:
            forks[by_proj[p.forked_from_id].owner_id] += 1
        for uid in collab[p.id] | authors[p.id]:
            if uid != p.owner_id:
                contributed[uid].add(p.id)
    awards = defaultdict(list)
    for a in Award.objects.filter(user_id__in=ids):
        awards[a.user_id].append(a)
    endorse = Counter(Endorsement.objects.filter(student_id__in=ids).values_list("student_id", flat=True))
    hack = Counter(uid for eid, uid in Event.attendees.through.objects.filter(event__category="Innovation").values_list("event_id", "user_id"))
    follower_counts = dict(Profile.followers.through.objects.values_list("profile_id").annotate(n=Count("id")))
    out = {}
    for pr in profiles:
        u = pr.user_id
        mine = owned[u]
        verified = [a for a in awards[u] if a.ledger_hash]
        stars = sum(p.nstars + p.base_stars for p in mine)
        q = [quality[p.id] for p in mine]
        led = [p for p in mine if p.ncollab > 0]
        lead = scoring.leadership_score(len(led), [p.ncollab + 1 for p in led],
                                        sum(a.award_type == "leadership" for a in awards[u]), pr.leadership_roles)
        inputs = {"repositories_created": len([p for p in mine if not p.forked_from_id]), "repositories_contributed": len(contributed[u]),
                  "project_stars": stars, "code_quality_score": round(sum(q) / len(q), 1) if q else 0,
                  "blockchain_verified_awards": len(verified), "hackathon_participation": hack[u],
                  "leadership_score": lead, "community_projects": sum(p.community for p in mine), "alumni_endorsements": endorse[u]}
        score, parts = scoring.innovation_score(inputs)
        views = sum(p.views for p in mine)
        out[u] = {
            "profile": pr, "user": pr.user, "inputs": inputs, "parts": parts, "innovation": score, "tier": scoring.tier(score),
            "collaboration": scoring.collaboration_score(len(contributed[u]), merged[u], issues_by[u], forks[u]), "leadership": lead,
            "quality": inputs["code_quality_score"], "projects": len(mine), "stars": stars, "views": views,
            "downloads": sum(p.downloads for p in mine), "followers": follower_counts.get(pr.id, 0),
            "activity": min(100, recent[u] * 4), "commits_90d": recent[u], "verified_awards": len(verified),
            "impact": round(min(100, stars * 3 + forks[u] * 8 + views / 10), 1),
            "tags": pr.tags + [t for p in mine for t in p.tags] + [p.primary_language for p in mine],
            "top": talent.top_category(pr.tags + [t for p in mine for t in p.tags] + [p.primary_language for p in mine]),
        }
    return out


def metrics_for(user_id):
    return all_metrics().get(user_id)


def talent_board(category=None, limit=30):
    rows = [{"id": m["user"].id, "name": m["user"].display, "username": m["user"].username, "school": m["profile"].school.name if m["profile"].school else "",
             "tags": m["tags"], "innovation": m["innovation"], "activity": m["activity"], "collaboration": m["collaboration"],
             "impact": m["impact"], "quality": m["quality"]} for m in all_metrics().values()]
    return talent.talent_rank(rows, category)[:limit]


# ----------------------------------------------------------------------------- schools
def school_board():
    metrics = all_metrics()
    per = defaultdict(list)
    for m in metrics.values():
        if m["profile"].school_id:
            per[m["profile"].school_id].append(m)
    cats = defaultdict(Counter)
    for p in Project.objects.select_related("owner__profile"):
        sid = getattr(getattr(p.owner, "profile", None), "school_id", None)
        if sid:
            cats[sid][p.category] += 1
    mentors = Counter(AlumniProfile.objects.filter(mentoring=True, user__is_active=True).values_list("user__profile__school_id", flat=True))
    rows = []
    for s in School.objects.all():
        ms = per.get(s.id, [])
        n = len(ms)
        avg = round(sum(m["innovation"] for m in ms) / n, 1) if n else 0
        projects = sum(m["projects"] for m in ms)
        commits = sum(m["commits_90d"] for m in ms)
        awards = sum(m["verified_awards"] for m in ms)
        part = round(sum(1 for m in ms if m["projects"]) / n * 100, 1) if n else 0
        # School score: 35% average innovation, 20% projects per student, 15% recent git activity, 15% verified awards, 15% participation
        score = round(avg * .35 + min(100, projects / n * 40 if n else 0) * .20 + min(100, commits / n * 3 if n else 0) * .15
                      + min(100, awards / n * 50 if n else 0) * .15 + part * .15, 1) if n else 0
        rows.append({"school": s, "students": n, "avg": avg, "projects": projects, "commits": commits, "awards": awards,
                     "participation": part, "score": score, "categories": dict(cats[s.id]), "mentors": mentors[s.id],
                     "top": sorted(ms, key=lambda m: -m["innovation"])[:5]})
    rows.sort(key=lambda r: (-r["score"], r["school"].name))
    for i, r in enumerate(rows, 1):
        r["rank"] = i
    return rows


def school_suggestions(row, board):
    """Rule-based suggestions for a school, comparing it with the other schools."""
    out, n = [], row["students"]
    allcats = Counter()
    for r in board:
        allcats.update(r["categories"])
    missing = [c for c, _ in allcats.most_common() if c not in row["categories"]][:2]
    if missing:
        out.append(("Innovation programmes", f"No projects yet in {' or '.join(missing)}. A club or term project would open these up."))
    if n and row["participation"] < 60:
        out.append(("Curriculum", f"Only {row['participation']:.0f}% of students have published a project. Build project time into a subject."))
    if row["mentors"] == 0:
        out.append(("Industry partnerships", "No alumni are mentoring. Invite graduates in industry to a career day."))
    if n and row["awards"] / n < 0.5:
        out.append(("STEM investment", "Few verified awards per student. Support entry to competitions and hackathons."))
    return out or [("Keep going", "This school is ahead on every measure we track.")]


# ----------------------------------------------------------------------------- contribution calendar
def contribution_grid(user_id, weeks=26, today=None):
    today = today or timezone.localdate()
    start = today - timedelta(days=today.weekday()) - timedelta(weeks=weeks - 1)
    counts = Counter(Activity.objects.filter(author_id=user_id, date__gte=start).values_list("date", flat=True))
    top = max(counts.values(), default=0)
    cols = []
    for w in range(weeks):
        col = []
        for d in range(7):
            day = start + timedelta(days=w * 7 + d)
            n = counts.get(day, 0)
            lvl = 0 if not n or day > today else 1 if n <= max(1, top * .25) else 2 if n <= top * .5 else 3 if n <= top * .75 else 4
            col.append({"date": day, "n": n, "level": lvl, "future": day > today})
        cols.append(col)
    months = []
    for w, col in enumerate(cols):
        label = col[0]["date"].strftime("%b")
        months.append(label if w == 0 or label != cols[w - 1][0]["date"].strftime("%b") else "")
    labels = ["Mon", "", "Wed", "", "Fri", "", ""]
    rows = [{"label": labels[d], "cells": [col[d] for col in cols]} for d in range(7)]
    return {"rows": rows, "months": months, "total": sum(counts.values())}


# ----------------------------------------------------------------------------- analytics
def analytics(today=None):
    today = today or timezone.localdate()
    year = today.year
    ps = list(Project.objects.all())
    cur = [p for p in ps if p.created.year == year]
    prev = [p for p in ps if p.created.year == year - 1]
    langs = insights.compare_counts(Counter(p.primary_language for p in prev), Counter(p.primary_language for p in cur))
    cats = insights.compare_counts(Counter(p.category for p in prev), Counter(p.category for p in cur))
    monthly = Counter((p.created.year, p.created.month) for p in ps)
    series = sorted(monthly.items())[-12:]
    profiles = Profile.objects.filter(user__role="student").count()
    publishing = len({p.owner_id for p in ps})
    return {
        "year": year, "sentences": insights.sentences(langs, cats), "langs": langs, "cats": cats,
        "months": [{"label": date(y, m, 1).strftime("%b %y"), "n": n} for (y, m), n in series],
        "projects": len(ps), "students": profiles, "engagement": round(publishing / profiles * 100) if profiles else 0,
        "alumni": AlumniProfile.objects.filter(user__is_active=True).count(), "mentors": AlumniProfile.objects.filter(mentoring=True, user__is_active=True).count(),
        "alumni_engaged": Endorsement.objects.values("alumnus").distinct().count(),
        "top_projects": sorted(ps, key=lambda p: -(p.views + p.stars * 10))[:5],
        "stars": sum(p.stars for p in ps),
    }


# ----------------------------------------------------------------------------- recommendations
def recommendations(user, metrics=None, today=None):
    today = today or timezone.localdate()
    m = metrics or metrics_for(user.id)
    tags = (m["tags"] if m else [])
    prof = getattr(user, "profile", None)
    if prof and not tags:
        tags = prof.tags
    mine = set(Project.objects.filter(owner=user).values_list("id", flat=True)) | set(user.contributing_to.values_list("id", flat=True))
    items = [{"id": p.id, "obj": p, "name": p.title, "tags": [*p.tags, p.primary_language, p.category]}
             for p in Project.objects.select_related("owner")]
    projects = recommend.rank(tags, items, exclude=mine, limit=4)
    mentors = [{"id": a.user_id, "obj": a, "name": a.user.display, "tags": [*(getattr(a.user, "profile", None) and a.user.profile.interests or []), a.industry, a.degree]}
               for a in AlumniProfile.objects.filter(mentoring=True, user__is_active=True).select_related("user", "user__profile")]
    mentors = recommend.rank(tags, mentors, limit=3)
    evs = [{"id": e.id, "obj": e, "name": e.title, "tags": [e.category, *e.title.lower().split()]}
           for e in Event.objects.filter(start_date__gte=today)[:40]]
    events = recommend.rank(tags + ["innovation"] if m and m["tags"] else tags, evs, limit=3)
    return {"projects": projects, "mentors": mentors, "events": events, "reason": recommend.reason}


# ----------------------------------------------------------------------------- resume
VARIANTS = {"cv": "Curriculum vitae", "university": "University application profile",
            "internship": "Internship profile", "scholarship": "Scholarship profile"}


def resume(user, variant="cv"):
    m = metrics_for(user.id)
    if not m:
        return None
    p = m["profile"]
    projects = list(Project.objects.filter(owner=user).order_by("-views")[:5])
    awards = list(user.awards.all())
    verified = [a for a in awards if a.ledger_hash]
    lead = f"Leadership score {m['leadership']:.0f}/100" + (f", {p.leadership_roles} school role(s)" if p.leadership_roles else "")
    summary = {
        "cv": f"{user.display} is a {p.form or 'high school'} student at {p.school or 'their school'} with {m['projects']} published project(s) and {m['stars']} star(s).",
        "university": f"{user.display} builds software projects, with an innovation score of {m['innovation']:.0f}/100 ({m['tier']}) and {len(verified)} ledger-verified award(s). {lead}.",
        "internship": f"{user.display} is available for hands-on work in {m['top'] or 'software'}: {m['commits_90d']} commits in the last 90 days across {m['projects']} project(s).",
        "scholarship": f"{user.display} shows merit through {len(verified)} verified award(s), community projects ({m['inputs']['community_projects']}) and {lead.lower()}.",
    }[variant]
    return {"m": m, "title": VARIANTS[variant], "variant": variant, "summary": summary, "projects": projects, "awards": awards,
            "skills": p.skills, "interests": p.interests, "endorsements": user.endorsements.select_related("alumnus")}
