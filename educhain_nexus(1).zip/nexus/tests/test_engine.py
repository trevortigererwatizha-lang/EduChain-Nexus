import os, sys
from datetime import date
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from engine import csvio, insights, ledger, recommend, scoring, talent  # noqa: E402

TODAY = date(2026, 11, 17)


def test_weights_sum_and_zero_one_hundred():
    assert abs(sum(scoring.WEIGHTS.values()) - 1) < 1e-9
    assert scoring.innovation_score({})[0] == 0
    full = {k: v for k, v in scoring.FULL_MARKS.items()}
    assert scoring.innovation_score(full)[0] == 100


def test_score_caps_and_partial():
    s, parts = scoring.innovation_score({"repositories_created": 3, "project_stars": 400})
    assert [p for p in parts if p["key"] == "project_stars"][0]["scaled"] == 100     # capped, not 1000
    assert s == round(50 * .15 + 100 * .10, 1)
    assert scoring.tier(85) == "Pioneer" and scoring.tier(5) == "Newcomer"


def test_code_quality_bounds():
    assert scoring.code_quality(True, True, 100, 5, 5, 5000) == 100
    assert scoring.code_quality(False, False, 0, 0, 0, 0) == 7.0


def test_ledger_detects_tampering():
    blocks, prev = [], ledger.GENESIS
    for i in range(4):
        b = ledger.make_block(i, "2026-01-0%dT10:00:00" % (i + 1), "award", {"n": i}, prev)
        blocks.append(b); prev = b["hash"]
    assert ledger.verify_chain(blocks)["ok"]
    blocks[1]["payload"]["n"] = 99
    r = ledger.verify_chain(blocks)
    assert not r["ok"] and r["broken_at"] == 1
    blocks[1]["payload"]["n"] = 1
    blocks[2]["prev_hash"] = "x"
    assert ledger.verify_chain(blocks)["broken_at"] == 2


def test_ledger_deterministic_and_order_independent_payload():
    a = ledger.make_block(0, "t", "k", {"a": 1, "b": 2}, ledger.GENESIS)
    b = ledger.make_block(0, "t", "k", {"b": 2, "a": 1}, ledger.GENESIS)
    assert a["hash"] == b["hash"]


def test_recommend_ranks_by_overlap():
    items = [{"id": 1, "name": "A", "tags": ["ai", "python"]}, {"id": 2, "name": "B", "tags": ["art"]},
             {"id": 3, "name": "C", "tags": ["ai"]}]
    r = recommend.rank(["AI", "Python"], items)
    assert [x[1]["id"] for x in r] == [1, 3] and r[0][0] > r[1][0]
    assert recommend.rank(["ai"], items, exclude={1, 3}) == []
    assert recommend.similarity([], ["a"]) == 0


def test_talent_categories_and_rank():
    assert talent.top_category(["python", "ai", "ml"]) == "Artificial Intelligence" or talent.top_category(["python", "ai", "ml"])
    assert talent.category_affinity(["blockchain", "ledger"])["Blockchain Development"] == 2
    base = dict(impact=50, activity=50, collaboration=50, quality=50)
    r = talent.talent_rank([dict(id=1, name="x", tags=["robotics"], innovation=40, **base),
                            dict(id=2, name="y", tags=["robotics"], innovation=80, **base),
                            dict(id=3, name="z", tags=["art"], innovation=99, **base)], "Robotics")
    assert [s["id"] for s in r] == [2, 1]


def test_insights_growth_and_sentences():
    assert insights.growth(100, 142) == 42.0 and insights.growth(0, 5) is None
    langs = insights.compare_counts({"Python": 50, "Java": 10}, {"Python": 71, "Java": 9})
    cats = insights.compare_counts({"AI": 8, "IoT": 5}, {"AI": 14, "IoT": 5, "Blockchain": 4})
    s = insights.sentences(langs, cats)
    assert s[0] == "Python projects increased by 42% this academic year."
    assert any("AI projects are the fastest-growing" in x for x in s) and any("Blockchain" in x for x in s)


def test_insight_ignores_tiny_base():
    langs = insights.compare_counts({"Rust": 1}, {"Rust": 5})
    assert insights.sentences(langs, []) == []


def test_csv_valid_and_errors():
    ok = csvio.parse("projects", "slug,title,owner_username,category,primary_language,created_date\nA-1,T,Bob,AI,Python,2026-01-02\n", TODAY)
    assert ok.ok and ok.rows[0]["owner_username"] == "bob" and ok.rows[0]["category"] == "AI"
    bad = csvio.parse("projects", "slug,title,owner_username,category,primary_language,created_date\na,T,b,Cooking,Py,2030-01-01\n", TODAY)
    assert {e["field"] for e in bad.errors} == {"category", "created_date"}
    assert "Missing column" in csvio.parse("schools", "name\nx\n", TODAY).errors[0]["message"]


def test_csv_duplicates_lists_dates_and_events():
    t = "school_code,name\nhre01,A\nHRE01,B\n"
    assert "duplicate" in csvio.parse("schools", t, TODAY).errors[0]["message"]
    r = csvio.parse("students", "username,full_name,school_code,skills\nx,X,s1,Python; SQL ;\n", TODAY)
    assert r.rows[0]["skills"] == ["Python", "SQL"] and r.rows[0]["school_code"] == "S1"
    e = csvio.parse("events", "title,category,start_date,end_date\nT,Sports,05/03/2026,01/03/2026\n", TODAY)
    assert e.errors[0]["field"] == "end_date"
    a = csvio.parse("activity", "project_slug,author_username,date,kind,message\np,u,2026-01-01,pull_request,m\n", TODAY)
    assert a.ok and a.rows[0]["kind"] == "pull_request"


def test_csv_write_guards_formulas_and_bom():
    out = csvio.write_csv(["a"], [["=SUM(A1)"], [["x", "y"]]])
    assert out.startswith("﻿".encode()) and b"'=SUM" in out and b"x; y" in out


def test_every_template_row_parses():
    for kind in csvio.SPECS:
        header = list(csvio.SPECS[kind]["cols"])
        text = csvio.write_csv(header, csvio.template_rows(kind)).decode("utf-8-sig")
        r = csvio.parse(kind, text, TODAY)
        assert r.ok, (kind, r.errors)
