"""End-to-end tests that need Django installed (pytest-django)."""
import pytest

pytest.importorskip("django")
from django.contrib.auth import get_user_model  # noqa: E402
from django.core.files.uploadedfile import SimpleUploadedFile  # noqa: E402
from django.core.management import call_command  # noqa: E402

from engine import ledger  # noqa: E402
from hub import services  # noqa: E402
from hub.models import ImportJob, LedgerBlock, Project, School  # noqa: E402

pytestmark = pytest.mark.django_db
U = get_user_model()
PAGES = ["/", "/for-you/", "/talent/", "/alumni/", "/schools/", "/schools/?view=cards", "/schools/?view=bars", "/calendar/", "/calendar/?view=list",
         "/calendar/nexus-calendar.ics", "/marketplace/", "/ledger/", "/insights/", "/apps/", "/apps/upload/"]


@pytest.fixture
def seeded():
    call_command("seed_demo")


def test_every_page_renders_for_a_student(client, seeded):
    s = U.objects.filter(role="student").first()
    client.force_login(s)
    for url in PAGES + [f"/u/{s.username}/", f"/u/{s.username}/resume/cv/"]:
        assert client.get(url).status_code == 200, url
    p = Project.objects.first()
    for tab in ("overview", "activity", "issues", "pulls", "forks"):
        assert client.get(f"/p/{p.slug}/?tab={tab}").status_code == 200


def test_login_required(client, seeded):
    assert client.get("/").status_code == 302 and client.get("/data/").status_code == 302


def test_ledger_is_valid_then_detects_tampering(seeded):
    assert services.verify_ledger()["ok"]
    b = LedgerBlock.objects.order_by("index")[3]
    b.payload = {**b.payload, "title": "forged"}
    b.save()
    r = services.verify_ledger()
    assert not r["ok"] and r["broken_at"] == b.index


def test_star_fork_and_issue(client, seeded):
    s = U.objects.filter(role="student").first()
    client.force_login(s)
    p = Project.objects.exclude(owner=s).first()
    client.post(f"/p/{p.slug}/star/")
    assert p.starred_by.filter(pk=s.pk).exists()
    client.post(f"/p/{p.slug}/fork/")
    f = Project.objects.get(owner=s, forked_from=p)
    assert f.ledger_hash
    client.post(f"/p/{p.slug}/issue/", {"kind": "issue", "message": "Typo in README"})
    assert p.activity.filter(kind="issue", message="Typo in README").exists()


def test_data_hub_admin_only(client, seeded):
    client.force_login(U.objects.filter(role="student").first())
    assert client.get("/data/").status_code == 403


def test_import_roundtrip_in_order(client):
    admin = U.objects.create_user("boss", password="x", role="admin")
    client.force_login(admin)

    def up(kind, text):
        client.post(f"/data/upload/{kind}/", {"file": SimpleUploadedFile("f.csv", text.encode())})
        job = ImportJob.objects.first()
        assert job.status == "previewed", job.errors
        client.post(f"/data/preview/{job.pk}/confirm/")
    up("schools", "school_code,name\nHRE01,Harare High\n")
    up("students", "username,full_name,school_code,skills\nada,Ada Moyo,HRE01,Python\n")
    up("projects", "slug,title,owner_username,category,primary_language,created_date\ncrop,Crop Doctor,ada,AI,Python,2026-01-02\n")
    up("awards", "username,title,award_type,issuer,date\nada,Coding Cup,competition,ZimTech,2026-03-01\n")
    assert School.objects.count() == 1 and Project.objects.get().ledger_hash
    assert LedgerBlock.objects.count() == 2 and services.verify_ledger()["ok"]


def test_bad_import_changes_nothing_and_unknown_school_is_caught(client):
    admin = U.objects.create_user("boss", password="x", role="admin")
    client.force_login(admin)
    client.post("/data/upload/students/", {"file": SimpleUploadedFile("s.csv", b"username,full_name,school_code\nada,Ada,NOPE\n")})
    job = ImportJob.objects.get()
    assert job.status == "failed" and "unknown school" in job.errors[0]["message"] and not U.objects.filter(username="ada").exists()


def test_exports(client, seeded):
    client.force_login(U.objects.get(username="admin"))
    for kind in ["schools", "students", "projects", "activity", "awards", "events", "alumni", "listings", "scores", "rankings", "ledger"]:
        r = client.get(f"/data/export/{kind}/")
        assert r.status_code == 200 and r.content.startswith("﻿".encode()), kind


def test_export_then_reimport_schools(client, seeded):
    admin = U.objects.get(username="admin")
    client.force_login(admin)
    body = client.get("/data/export/schools/").content
    client.post("/data/upload/schools/", {"file": SimpleUploadedFile("s.csv", body)})
    assert ImportJob.objects.first().status == "previewed"


def test_scores_in_range(seeded):
    for m in services.all_metrics().values():
        assert 0 <= m["innovation"] <= 100 and 0 <= m["collaboration"] <= 100


# ----------------------------------------------------------------------------- registration and app uploads
import io  # noqa: E402
import zipfile  # noqa: E402

REG = {"first_name": "Ada", "last_name": "Moyo", "username": "ada.m", "email": "ada@example.org", "role": "student", "password1": "Sturdy-pass-9", "password2": "Sturdy-pass-9",
       "agree": "on", "website": ""}


def make_zip(files):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for n, d in files.items():
            z.writestr(n, d)
    return buf.getvalue()


def zupload(data, name="app.zip"):
    return SimpleUploadedFile(name, data, content_type="application/zip")


@pytest.fixture
def media(settings, tmp_path):
    settings.MEDIA_ROOT = tmp_path
    return tmp_path


def member(email="m@example.org", role="student", name=None):
    u = U.objects.create_user(name or email.split("@")[0], email=email, password="x", role=role)
    from hub.models import Profile
    Profile.objects.create(user=u)
    return u


def test_register_is_pending_and_cannot_sign_in(client):
    r = client.post("/register/", REG)
    assert r.status_code == 302
    u = U.objects.get(username="ada.m")
    assert u.status == "pending" and not u.is_active
    r = client.post("/login/", {"username": "ada.m", "password": "Sturdy-pass-9"})
    assert b"waiting for an administrator" in r.content
    r = client.post("/login/", {"username": "ada.m", "password": "wrong"})
    assert b"waiting" not in r.content


def test_admin_approves_then_user_signs_in(client):
    client.post("/register/", REG)
    admin = U.objects.create_user("boss", password="x", role="admin")
    client.force_login(admin)
    assert client.get("/registrations/").status_code == 200
    u = U.objects.get(username="ada.m")
    client.post(f"/registrations/{u.pk}/approve/")
    u.refresh_from_db()
    assert u.status == "approved" and u.is_active and u.decided_by == admin
    client.logout()
    assert client.post("/login/", {"username": "ada.m", "password": "Sturdy-pass-9"}).status_code == 302


def test_rejection_shows_reason(client):
    client.post("/register/", REG)
    admin = U.objects.create_user("boss", password="x", role="admin")
    client.force_login(admin)
    u = U.objects.get(username="ada.m")
    client.post(f"/registrations/{u.pk}/reject/", {"note": "Not a member of the school"})
    client.logout()
    r = client.post("/login/", {"username": "ada.m", "password": "Sturdy-pass-9"})
    assert b"not approved" in r.content and b"Not a member" in r.content


def test_register_validation(client):
    U.objects.create_user("ada.m", email="taken@example.org", password="x")
    assert U.objects.count() == 1
    assert b"taken" in client.post("/register/", REG).content
    bad = {**REG, "username": "new.one", "password1": "12345678", "password2": "12345678"}
    assert U.objects.filter(username="new.one").count() == 0 and client.post("/register/", bad).status_code == 200
    assert U.objects.filter(username="new.one").count() == 0
    assert client.post("/register/", {**REG, "username": "bot", "website": "spam"}).status_code == 200 and not U.objects.filter(username="bot").exists()
    assert client.post("/register/", {**REG, "username": "alum", "email": "a@b.org", "role": "alumni"}).status_code == 200      # needs graduation year
    assert not U.objects.filter(username="alum").exists()


def test_only_admin_sees_registrations_and_cannot_pick_admin_role(client):
    client.force_login(member())
    assert client.get("/registrations/").status_code == 403
    client.logout()
    client.post("/register/", {**REG, "role": "admin"})
    assert not U.objects.filter(username="ada.m").exists()


def test_pending_people_are_not_listed(client, seeded):
    client.post("/register/", {**REG, "role": "alumni", "graduation_year": 2020, "username": "pend.alum"})
    client.force_login(U.objects.filter(role="student").first())
    assert b"pend.alum" not in client.get("/alumni/").content
    assert client.get("/u/pend.alum/").status_code == 404


def test_upload_view_edit_download_flow(client, media):
    owner, other = member("owner@example.org"), member("other@example.org")
    client.force_login(owner)
    r = client.post("/apps/upload/", {"title": "Quiz app", "description": "d", "tags": "py, web", "file": zupload(make_zip({"quiz/main.py": "print('v1')", "quiz/img.png": b"\x89PNG\x00"}))})
    from hub.models import AppPackage
    pkg = AppPackage.objects.get()
    assert r.status_code == 302 and pkg.latest.number == 1 and pkg.latest.file_count == 2
    client.force_login(other)
    page = client.get(f"/apps/{pkg.pk}/?file=quiz/main.py")
    assert b"print(&#x27;v1&#x27;)" in page.content or b"print('v1')" in page.content
    assert b"Edit this file" in page.content
    d = client.get(f"/apps/{pkg.pk}/download/")
    assert d.status_code == 200 and d["Content-Type"] == "application/zip" and "attachment" in d["Content-Disposition"] and d["X-Content-Type-Options"] == "nosniff"
    got = zipfile.ZipFile(io.BytesIO(b"".join(d.streaming_content)))
    assert got.read("quiz/main.py") == b"print('v1')"
    import hashlib
    base = hashlib.sha256(b"print('v1')").hexdigest()
    client.post(f"/apps/{pkg.pk}/edit/", {"file": "quiz/main.py", "content": "print('v2')", "base": base, "note": "bump"})
    pkg.refresh_from_db()
    assert pkg.latest.number == 2 and pkg.latest.uploaded_by == other
    v1 = zipfile.ZipFile(io.BytesIO(appstore_bytes(pkg, 1)))
    v2 = zipfile.ZipFile(io.BytesIO(appstore_bytes(pkg, 2)))
    assert v1.read("quiz/main.py") == b"print('v1')" and v2.read("quiz/main.py") == b"print('v2')" and v2.read("quiz/img.png") == b"\x89PNG\x00"


def appstore_bytes(pkg, n):
    from hub import appstore
    return appstore.read_bytes(pkg.versions.get(number=n))


def test_stale_edit_is_refused_and_closed_app_cannot_be_edited(client, media):
    from hub.models import AppPackage
    import hashlib
    owner, other = member("owner@example.org"), member("other@example.org")
    client.force_login(owner)
    client.post("/apps/upload/", {"title": "A", "file": zupload(make_zip({"a.py": "one"}))})
    pkg = AppPackage.objects.get()
    base = hashlib.sha256(b"one").hexdigest()
    client.post(f"/apps/{pkg.pk}/edit/", {"file": "a.py", "content": "two", "base": base})
    client.force_login(other)
    r = client.post(f"/apps/{pkg.pk}/edit/", {"file": "a.py", "content": "three", "base": base})
    assert b"while you were editing" in r.content and pkg.versions.count() == 2
    client.force_login(owner)
    client.post(f"/apps/{pkg.pk}/settings/", {"title": "A", "description": "", "tags": ""})      # open_edit unchecked
    client.force_login(other)
    client.post(f"/apps/{pkg.pk}/edit/", {"file": "a.py", "content": "four", "base": hashlib.sha256(b"two").hexdigest()})
    assert pkg.versions.count() == 2
    assert client.post(f"/apps/{pkg.pk}/version/", {"file": zupload(make_zip({"a.py": "x"}))}).status_code == 302 and pkg.versions.count() == 2


def test_bad_zips_are_refused(client, media):
    from hub.models import AppPackage
    client.force_login(member())
    for data in (b"not a zip", make_zip({"ok.txt": "x"})[:30]):
        client.post("/apps/upload/", {"title": "Bad", "file": zupload(data)})
    evil = io.BytesIO()
    with zipfile.ZipFile(evil, "w") as z:
        z.writestr(zipfile.ZipInfo("../../escape.py"), "x")
    client.post("/apps/upload/", {"title": "Evil", "file": zupload(evil.getvalue())})
    assert AppPackage.objects.count() == 0 and not list(media.rglob("*.zip"))


def test_only_owner_can_restore_and_delete(client, media):
    from hub.models import AppPackage
    owner, other = member("owner@example.org"), member("other@example.org")
    client.force_login(owner)
    client.post("/apps/upload/", {"title": "A", "file": zupload(make_zip({"a.py": "one"}))})
    pkg = AppPackage.objects.get()
    client.post(f"/apps/{pkg.pk}/version/", {"file": zupload(make_zip({"a.py": "two"}))})
    client.force_login(other)
    client.post(f"/apps/{pkg.pk}/restore/1/")
    client.post(f"/apps/{pkg.pk}/delete/")
    assert pkg.versions.count() == 2 and AppPackage.objects.count() == 1
    client.force_login(owner)
    client.post(f"/apps/{pkg.pk}/restore/1/")
    assert pkg.versions.count() == 3 and appstore_bytes(pkg, 3) == appstore_bytes(pkg, 1)
    client.post(f"/apps/{pkg.pk}/delete/")
    assert AppPackage.objects.count() == 0 and not list(media.rglob("*.zip"))


def test_app_pages_render_for_every_member_type(client, media):
    for role in ("student", "teacher", "alumni", "partner"):
        u = member(f"{role}@example.org", role)
        client.force_login(u)
        assert client.get("/apps/").status_code == 200 and client.get("/apps/upload/").status_code == 200 and client.get(f"/u/{u.username}/").status_code in (200, 404)
