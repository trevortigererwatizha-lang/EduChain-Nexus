import io
import os
import sys
import zipfile

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from engine import ziputil as Z  # noqa: E402


def make(files, compress=zipfile.ZIP_DEFLATED):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", compress) as z:
        for name, data in files.items():
            z.writestr(name, data)
    return buf.getvalue()


def test_inspect_lists_files_and_text_flags():
    data = make({"app/main.py": "print(1)", "app/logo.png": b"\x89PNG\x00\x01", "app/README.md": "# hi", "app/": ""})
    r = Z.inspect(data)
    assert r["count"] == 3 and r["total"] > 0
    flags = {f["name"]: f["text"] for f in r["files"]}
    assert flags["app/main.py"] and flags["app/README.md"] and not flags["app/logo.png"]
    assert Z.top_level(r["files"]) == "app/"


@pytest.mark.parametrize("bad", ["../evil.py", "/etc/passwd", "a/../../b", "C:/x.txt", "a\\b.txt"])
def test_zip_slip_paths_rejected(bad):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr(zipfile.ZipInfo(bad), "x")
    with pytest.raises(Z.ZipRejected):
        Z.inspect(buf.getvalue())


def test_not_a_zip_and_damaged():
    with pytest.raises(Z.ZipRejected, match="not a .zip"):
        Z.inspect(b"hello world")
    with pytest.raises(Z.ZipRejected, match="damaged"):
        Z.inspect(b"PK\x03\x04" + b"garbage" * 10)


def test_symlink_rejected():
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        zi = zipfile.ZipInfo("link")
        zi.external_attr = (0o120777 << 16)
        z.writestr(zi, "/etc/passwd")
    with pytest.raises(Z.ZipRejected, match="symbolic link"):
        Z.inspect(buf.getvalue())


def test_zip_bomb_ratio_rejected():
    with pytest.raises(Z.ZipRejected, match="suspiciously"):
        Z.inspect(make({"zeros.txt": b"\x00" * (15 * 1024 * 1024)}))


def test_too_many_files_and_oversize_upload():
    many = make({f"f{i}.txt": "x" for i in range(Z.MAX_FILES + 1)})
    with pytest.raises(Z.ZipRejected, match="more than"):
        Z.inspect(many)
    with pytest.raises(Z.ZipRejected, match="larger than"):
        Z.inspect(b"PK\x03\x04" + b"0" * (Z.MAX_UPLOAD + 1))


def test_duplicate_names_rejected():
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("a.txt", "1")
        z.writestr("a.txt", "2")
    with pytest.raises(Z.ZipRejected, match="twice"):
        Z.inspect(buf.getvalue())


def test_password_protected_rejected():
    data = bytearray(make({"a.txt": "secret"}))
    # set the encrypted flag in both the local header and the central directory
    for sig in (b"PK\x03\x04", b"PK\x01\x02"):
        i = data.find(sig)
        off = i + (6 if sig == b"PK\x03\x04" else 8)
        data[off] |= 1
    with pytest.raises(Z.ZipRejected, match="password"):
        Z.inspect(bytes(data))


def test_preview_text_binary_and_truncation():
    data = make({"a.py": "print('é')", "b.bin": b"\x00\x01", "c.txt": "x" * (Z.MAX_PREVIEW + 10), "d.py": b"\xff\xfe\xfa"})
    assert Z.preview_text(data, "a.py") == "print('é')"
    assert Z.preview_text(data, "b.bin") is None
    assert "Preview cut off" in Z.preview_text(data, "c.txt")
    assert Z.preview_text(data, "d.py") is None
    with pytest.raises(Z.ZipRejected):
        Z.read_member(data, "missing.py")


def test_replace_member_keeps_others_and_original():
    data = make({"app/main.py": "old", "app/data.bin": b"\x00\x01\x02", "app/sub/": "", "app/sub/x.txt": "keep"})
    new = Z.replace_member(data, "app/main.py", b"new code")
    assert Z.read_member(new, "app/main.py")[0] == b"new code"
    assert Z.read_member(new, "app/data.bin")[0] == b"\x00\x01\x02" and Z.read_member(new, "app/sub/x.txt")[0] == b"keep"
    assert Z.read_member(data, "app/main.py")[0] == b"old"
    assert [f["name"] for f in Z.inspect(new)["files"]] == [f["name"] for f in Z.inspect(data)["files"]]


def test_replace_member_refuses_binary_missing_and_huge():
    data = make({"a.py": "x", "b.png": b"\x89PNG"})
    with pytest.raises(Z.ZipRejected, match="text files"):
        Z.replace_member(data, "b.png", b"x")
    with pytest.raises(Z.ZipRejected, match="not in the zip"):
        Z.replace_member(data, "c.py", b"x")
    with pytest.raises(Z.ZipRejected, match="limited"):
        Z.replace_member(data, "a.py", b"x" * (Z.MAX_EDIT + 1))


def test_depth_rows():
    rows = Z.depth_rows(Z.inspect(make({"a/b/c.py": "x", "a/b/": "", "a/": ""}))["files"])
    assert {r["base"]: r["depth"] for r in rows} == {"a/": 0, "b/": 1, "c.py": 2}
