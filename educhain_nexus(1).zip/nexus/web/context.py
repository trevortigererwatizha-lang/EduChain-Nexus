def pending_registrations(request):
    """Badge count for administrators in the main navigation."""
    u = getattr(request, "user", None)
    if u is not None and u.is_authenticated and u.is_data_admin:
        from django.contrib.auth import get_user_model
        return {"pending_count": get_user_model().objects.filter(status="pending").count()}
    return {}
