import re

from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError

from hub.models import School

User = get_user_model()
SELF_ROLES = [("student", "Student"), ("teacher", "Teacher"), ("alumni", "Alumni"), ("partner", "Recruiter or university")]


class RegisterForm(forms.Form):
    first_name = forms.CharField(max_length=60)
    last_name = forms.CharField(max_length=60)
    username = forms.CharField(max_length=40, help_text="Letters, numbers, dot, dash or underscore")
    email = forms.EmailField(max_length=120)
    role = forms.ChoiceField(choices=SELF_ROLES)
    school = forms.ModelChoiceField(School.objects.none(), required=False, empty_label="Not at a listed school")
    graduation_year = forms.IntegerField(required=False, min_value=1950, max_value=2100, label="Graduation year (alumni)")
    note = forms.CharField(max_length=300, required=False, widget=forms.Textarea(attrs={"rows": 3}),
                           label="Anything the administrator should know", help_text="For example your class, or how you know the school")
    password1 = forms.CharField(widget=forms.PasswordInput, label="Password")
    password2 = forms.CharField(widget=forms.PasswordInput, label="Repeat password")
    agree = forms.BooleanField(label="I agree that my profile and work will be visible to other signed-in members, and if I am under 18 a parent or teacher knows I am joining.")
    website = forms.CharField(required=False, widget=forms.HiddenInput)   # honeypot: real people leave it empty

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.fields["school"].queryset = School.objects.all()

    def clean_username(self):
        u = self.cleaned_data["username"].strip()
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._\-]*", u):
            raise ValidationError("Use letters, numbers, dot, dash or underscore only.")
        if User.objects.filter(username__iexact=u).exists():
            raise ValidationError("That username is taken. Try another.")
        return u.lower()

    def clean_email(self):
        e = self.cleaned_data["email"].strip().lower()
        if User.objects.filter(email__iexact=e).exists():
            raise ValidationError("An account with this email already exists. If it is yours, ask the administrator.")
        return e

    def clean_website(self):
        if self.cleaned_data.get("website"):
            raise ValidationError("Registration could not be completed.")
        return ""

    def clean(self):
        d = super().clean()
        p1, p2 = d.get("password1"), d.get("password2")
        if p1 and p2 and p1 != p2:
            self.add_error("password2", "The passwords do not match.")
        elif p1:
            try:
                validate_password(p1, User(username=d.get("username", ""), first_name=d.get("first_name", ""), email=d.get("email", "")))
            except ValidationError as e:
                self.add_error("password1", e)
        if d.get("role") == "alumni" and not d.get("graduation_year"):
            self.add_error("graduation_year", "Alumni need a graduation year.")
        return d


class LoginForm(AuthenticationForm):
    """Tells people whose registration is waiting or refused why they cannot sign in, instead of 'wrong password'."""

    def clean(self):
        username, password = self.cleaned_data.get("username"), self.cleaned_data.get("password")
        if username and password:
            u = User.objects.filter(username__iexact=username).first()
            if u and not u.is_active and u.check_password(password):
                if u.status == User.Status.PENDING:
                    raise ValidationError("Your registration is waiting for an administrator to approve it. You will be able to sign in once it is.", code="pending")
                if u.status == User.Status.REJECTED:
                    raise ValidationError("Your registration was not approved." + (f" Reason: {u.decision_note}" if u.decision_note else ""), code="rejected")
                raise ValidationError("This account has been switched off. Contact the administrator.", code="inactive")
        return super().clean()
