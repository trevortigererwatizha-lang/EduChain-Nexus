(function () {
  var root = document.documentElement;
  function css(n) { return getComputedStyle(root).getPropertyValue(n).trim(); }
  function safe(f) { try { return f(); } catch (e) { return null; } }
  var s = safe(function () { return localStorage.getItem("nx-theme"); });
  if (s) root.setAttribute("data-theme", s);
  var tb = document.getElementById("theme-toggle");
  if (tb) tb.addEventListener("click", function () {
    var dark = root.getAttribute("data-theme") === "dark" || (!root.getAttribute("data-theme") && matchMedia("(prefers-color-scheme: dark)").matches);
    var n = dark ? "light" : "dark"; root.setAttribute("data-theme", n); safe(function () { localStorage.setItem("nx-theme", n); }); draw();
  });
  var mb = document.getElementById("menu-btn");
  if (mb) mb.addEventListener("click", function () { var o = document.querySelector(".nav").classList.toggle("open"); mb.setAttribute("aria-expanded", o); });
  document.querySelectorAll(".drop").forEach(function (d) {
    var inp = d.querySelector("input[type=file]"), nm = d.querySelector(".fname");
    ["dragover", "dragenter"].forEach(function (e) { d.addEventListener(e, function (ev) { ev.preventDefault(); d.classList.add("over"); }); });
    ["dragleave", "drop"].forEach(function (e) { d.addEventListener(e, function () { d.classList.remove("over"); }); });
    d.addEventListener("drop", function (ev) { ev.preventDefault(); if (ev.dataTransfer.files.length) { inp.files = ev.dataTransfer.files; show(); } });
    inp.addEventListener("change", show); function show() { if (nm && inp.files[0]) nm.textContent = inp.files[0].name; }
  });
  // charts (insights page)
  var el = document.getElementById("chart-data"), D = el ? JSON.parse(el.textContent) : null, live = [];
  function mk(id, cfg) { var c = document.getElementById(id); if (!c || !window.Chart) return; cfg.options = Object.assign({responsive: true, maintainAspectRatio: false}, cfg.options || {}); live.push(new Chart(c, cfg)); }
  function draw() {
    live.forEach(function (c) { c.destroy(); }); live = [];
    if (!D || !window.Chart) return;
    var ink = css("--muted"), line = css("--line"), brand = css("--brand");
    Chart.defaults.font.family = css("--sans").replace(/"/g, "");
    function ax(fmt) { return {x: {ticks: {color: ink}, grid: {display: false}}, y: {ticks: {color: ink, callback: fmt}, grid: {color: line}, border: {display: false}, beginAtZero: true}}; }
    function lg() { return {labels: {color: ink, usePointStyle: true, boxWidth: 10}}; }
    mk("c-months", {type: "bar", data: {labels: D.months.map(function (m) { return m.label; }), datasets: [{data: D.months.map(function (m) { return m.n; }), backgroundColor: brand, borderRadius: 4}]}, options: {scales: ax(), plugins: {legend: {display: false}}}});
    mk("c-langs", {type: "bar", data: {labels: D.langs.map(function (l) { return l.label; }), datasets: [{label: D.prevYear, data: D.langs.map(function (l) { return l.prev; }), backgroundColor: css("--c1"), borderRadius: 4}, {label: D.year, data: D.langs.map(function (l) { return l.cur; }), backgroundColor: brand, borderRadius: 4}]}, options: {scales: ax(), plugins: {legend: lg()}}});
    mk("c-cats", {type: "bar", data: {labels: D.cats.map(function (l) { return l.label; }), datasets: [{label: D.prevYear, data: D.cats.map(function (l) { return l.prev; }), backgroundColor: css("--c1"), borderRadius: 4}, {label: D.year, data: D.cats.map(function (l) { return l.cur; }), backgroundColor: brand, borderRadius: 4}]}, options: {indexAxis: "y", scales: {x: ax().y, y: {ticks: {color: css("--ink")}, grid: {display: false}}}, plugins: {legend: lg()}}});
  }
  window.addEventListener("load", draw);
})();
