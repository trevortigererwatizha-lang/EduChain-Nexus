from django import template
from django.utils.html import format_html

register = template.Library()


@register.filter
def num(v):
    """1234 -> 1.2k"""
    v = v or 0
    return f"{v / 1000:.1f}k" if v >= 1000 else str(v)


@register.filter
def score(v):
    return "–" if v is None else f"{v:.0f}"


@register.filter
def pctchg(v):
    """Growth percentage with sign; None when not comparable."""
    if v is None:
        return "new"
    return f"{'+' if v > 0 else '−' if v < 0 else ''}{abs(v):g}%"


@register.filter
def trend(v):
    return "flat" if v is None or v == 0 else "up" if v > 0 else "down"


@register.filter
def short(h):
    return f"{h[:8]}…{h[-6:]}" if h else ""


@register.filter
def initials(name):
    parts = (name or "?").split()
    return (parts[0][0] + (parts[-1][0] if len(parts) > 1 else "")).upper()


@register.filter
def bar(v, top=100):
    try:
        return max(0, min(100, float(v) / float(top) * 100)) if top else 0
    except (TypeError, ValueError):
        return 0


@register.filter
def getitem(d, k):
    return d.get(k) if hasattr(d, "get") else None


@register.filter
def hue(name):
    """A stable 0-359 hue for avatars and language dots."""
    return sum(ord(c) * (i + 3) for i, c in enumerate(str(name))) % 360


@register.simple_tag
def verified(h):
    if not h:
        return format_html('<span class="vbadge off" title="Not recorded on the ledger">Unverified</span>')
    return format_html('<span class="vbadge" title="Ledger record {}">Verified</span>', h[:12])


@register.filter
def label(key):
    return str(key).replace("_", " ").capitalize()
