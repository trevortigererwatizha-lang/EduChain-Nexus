from django.urls import path

from . import views as v
from . import views_apps as a
from . import views_reg as r

app_name = "web"
urlpatterns = [
    path("register/", r.register, name="register"),
    path("register/done/", r.register_done, name="register_done"),
    path("registrations/", r.registrations, name="registrations"),
    path("registrations/<int:pk>/<str:action>/", r.decide, name="decide"),
    path("", v.explore, name="explore"),
    path("projects/new/", v.project_new, name="project_new"),
    path("p/<slug:slug>/", v.project_detail, name="project"),
    path("p/<slug:slug>/star/", v.project_star, name="star"),
    path("p/<slug:slug>/fork/", v.project_fork, name="fork"),
    path("p/<slug:slug>/issue/", v.project_issue, name="issue"),
    path("p/<slug:slug>/close/<int:pk>/", v.project_close, name="close"),
    path("u/<str:username>/", v.profile, name="profile"),
    path("u/<str:username>/follow/", v.follow, name="follow"),
    path("u/<str:username>/endorse/", v.endorse, name="endorse"),
    path("u/<str:username>/resume/<str:variant>/", v.resume, name="resume"),
    path("talent/", v.talent_view, name="talent"),
    path("alumni/", v.alumni_list, name="alumni"),
    path("alumni/<str:username>/mentor/", v.mentor_request, name="mentor"),
    path("apps/", a.apps_list, name="apps"),
    path("apps/upload/", a.app_upload, name="app_upload"),
    path("apps/<int:pk>/", a.app_detail, name="app"),
    path("apps/<int:pk>/download/", a.app_download, name="app_download"),
    path("apps/<int:pk>/edit/", a.app_edit, name="app_edit"),
    path("apps/<int:pk>/version/", a.app_new_version, name="app_version"),
    path("apps/<int:pk>/settings/", a.app_settings, name="app_settings"),
    path("apps/<int:pk>/restore/<int:number>/", a.app_restore, name="app_restore"),
    path("apps/<int:pk>/delete/", a.app_delete, name="app_delete"),
    path("schools/", v.schools, name="schools"),
    path("schools/<str:code>/", v.school_detail, name="school"),
    path("calendar/", v.calendar_view, name="calendar"),
    path("calendar/nexus-calendar.ics", v.calendar_ics, name="ics"),
    path("calendar/<int:pk>/register/", v.event_register, name="register"),
    path("marketplace/", v.marketplace, name="marketplace"),
    path("marketplace/<slug:slug>/", v.listing_detail, name="listing"),
    path("ledger/", v.ledger_view, name="ledger"),
    path("insights/", v.insights, name="insights"),
    path("for-you/", v.for_you, name="foryou"),
]
