import calendar as pycal
from collections import Counter
from datetime import date, timedelta

from django.contrib import messages
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from django.db.models import Count, Q
from django.http import Http404, HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.utils.text import slugify
from django.views.decorators.http import require_POST

from engine import csvio, talent
from hub import services as S
from hub.models import (Activity, AlumniProfile, Endorsement, Event, Interest, LedgerBlock, Listing, Mentorship, Profile, Project, School, audit)

User = get_user_model()
SORTS = {"trending": ("-views",), "new": ("-created",), "stars": ()}


def page(request, tpl, nav, **ctx):
    return render(request, tpl, {"nav": nav, **ctx})


# ----------------------------------------------------------------------------- explore
@login_required
def explore(request):
    q = request.GET.get("q", "").strip()[:80]
    cat, lang = request.GET.get("category", ""), request.GET.get("language", "")
    sort = request.GET.get("sort", "trending")
    qs = Project.objects.select_related("owner", "owner__profile__school").annotate(nstars=Count("starred_by", distinct=True))
    if q:
        qs = qs.filter(Q(title__icontains=q) | Q(description__icontains=q) | Q(owner__username__icontains=q))
    if cat in csvio.CATEGORIES:
        qs = qs.filter(category=cat)
    if lang:
        qs = qs.filter(primary_language__iexact=lang)
    rows = list(qs)
    for p in rows:
        p.star_total = p.nstars + p.base_stars
    rows.sort(key=lambda p: (-p.star_total, p.title) if sort == "stars" else (-p.created.toordinal(), p.title) if sort == "new" else (-(p.views + p.star_total * 10), p.title))
    langs = sorted(set(Project.objects.values_list("primary_language", flat=True)))
    view = request.GET.get("view") if request.GET.get("view") in ("cards", "list") else "cards"
    return page(request, "web/explore.html", "explore", projects=rows[:60], total=len(rows), q=q, f={"category": cat, "language": lang, "sort": sort},
                categories=csvio.CATEGORIES, languages=langs, view=view,
                trending_users=sorted(S.all_metrics().values(), key=lambda m: -m["innovation"])[:5])


@login_required
def project_detail(request, slug):
    p = get_object_or_404(Project.objects.select_related("owner", "owner__profile__school", "forked_from"), slug=slug)
    if request.user != p.owner:
        Project.objects.filter(pk=p.pk).update(views=p.views + 1)
    tab = request.GET.get("tab", "overview")
    act = list(p.activity.select_related("author"))
    commits, issues, pulls = ([a for a in act if a.kind == k] for k in ("commit", "issue", "pull_request"))
    contributors = Counter(a.author for a in act)
    return page(request, "web/project.html", "explore", p=p, tab=tab if tab in ("overview", "activity", "issues", "pulls", "forks") else "overview",
                commits=commits[:30], issues=issues, pulls=pulls, contributors=contributors.most_common(8), forks=p.forks.select_related("owner"),
                starred=p.starred_by.filter(pk=request.user.pk).exists(), nstars=p.stars, collaborators=p.collaborators.all(),
                can_edit=request.user == p.owner or request.user.is_data_admin, listing=p.listings.first())


@login_required
@require_POST
def project_star(request, slug):
    p = get_object_or_404(Project, slug=slug)
    if p.starred_by.filter(pk=request.user.pk).exists():
        p.starred_by.remove(request.user)
    else:
        p.starred_by.add(request.user)
    return redirect("web:project", slug)


@login_required
@require_POST
def project_fork(request, slug):
    src = get_object_or_404(Project, slug=slug)
    base = f"{src.slug}-{request.user.username}"[:55]
    new_slug, n = base, 1
    while Project.objects.filter(slug=new_slug).exists():
        n += 1
        new_slug = f"{base}-{n}"
    f = Project.objects.create(slug=new_slug, title=src.title, owner=request.user, category=src.category, primary_language=src.primary_language,
                               description=src.description, readme=src.readme, tags=src.tags, forked_from=src, created=timezone.localdate())
    S.anchor_project(f)
    messages.success(request, f"Forked to your account as {f.slug}.")
    return redirect("web:project", f.slug)


@login_required
@require_POST
def project_issue(request, slug):
    p = get_object_or_404(Project, slug=slug)
    text = request.POST.get("message", "").strip()[:160]
    kind = request.POST.get("kind", "issue")
    if text and kind in ("issue", "pull_request"):
        Activity.objects.create(project=p, author=request.user, date=timezone.localdate(), kind=kind, message=text, done=False)
        messages.success(request, "Added.")
    else:
        messages.error(request, "Write a short title first.")
    return redirect(f"/p/{slug}/?tab={'pulls' if kind == 'pull_request' else 'issues'}")


@login_required
@require_POST
def project_close(request, slug, pk):
    p = get_object_or_404(Project, slug=slug)
    if request.user == p.owner or request.user.is_data_admin:
        p.activity.filter(pk=pk, kind__in=("issue", "pull_request")).update(done=True)
    return redirect("web:project", slug)


@login_required
def project_new(request):
    if request.method == "POST":
        title = request.POST.get("title", "").strip()[:120]
        cat, lang = request.POST.get("category", ""), request.POST.get("primary_language", "").strip()[:30]
        if not title or cat not in csvio.CATEGORIES or not lang:
            messages.error(request, "Give the project a title, a category and a main language.")
        else:
            base = slugify(title)[:50] or "project"
            slug, n = base, 1
            while Project.objects.filter(slug=slug).exists():
                n += 1
                slug = f"{base}-{n}"
            tags = [t.strip() for t in request.POST.get("tags", "").split(",") if t.strip()][:10]
            p = Project.objects.create(slug=slug, title=title, owner=request.user, category=cat, primary_language=lang, tags=tags,
                                       description=request.POST.get("description", "")[:600], readme=request.POST.get("readme", "")[:20000])
            S.anchor_project(p)
            audit(request.user, "project.create", {"slug": slug}, request)
            return redirect("web:project", slug)
    return page(request, "web/project_new.html", "explore", categories=csvio.CATEGORIES)


# ----------------------------------------------------------------------------- people
@login_required
def profile(request, username):
    u = get_object_or_404(User, username=username)
    pr = getattr(u, "profile", None)
    if not pr or (not u.is_active and not request.user.is_data_admin):
        raise Http404
    m = S.metrics_for(u.id)
    projects = Project.objects.filter(owner=u).annotate(nstars=Count("starred_by", distinct=True))
    return page(request, "web/profile.html", "people", u=u, pr=pr, m=m, projects=projects, grid=S.contribution_grid(u.id), awards=u.awards.all(),
                endorsements=u.endorsements.select_related("alumnus"), alumni=getattr(u, "alumni", None),
                following=pr.followers.filter(pk=request.user.pk).exists(), is_me=request.user == u, variants=S.VARIANTS,
                categories=talent.category_affinity(m["tags"]) if m else {}, apps=u.app_packages.all(), mentoring=u.mentor_requests.select_related("mentor") if request.user == u else [])


@login_required
@require_POST
def follow(request, username):
    pr = get_object_or_404(Profile, user__username=username)
    if pr.user != request.user:
        (pr.followers.remove if pr.followers.filter(pk=request.user.pk).exists() else pr.followers.add)(request.user)
    return redirect("web:profile", username)


@login_required
def resume(request, username, variant):
    u = get_object_or_404(User, username=username)
    if variant not in S.VARIANTS:
        raise Http404
    data = S.resume(u, variant)
    if not data:
        raise Http404
    audit(request.user, "resume.view", {"student": u.pk, "variant": variant}, request)
    return page(request, "web/resume.html", "people", u=u, r=data, variants=S.VARIANTS)


@login_required
def talent_view(request):
    cat = request.GET.get("category", "")
    cat = cat if cat in talent.CATEGORIES else None
    return page(request, "web/talent.html", "people", rows=S.talent_board(cat), categories=list(talent.CATEGORIES), cat=cat)


@login_required
def alumni_list(request):
    qs = AlumniProfile.objects.filter(user__is_active=True).select_related("user", "user__profile__school")
    industry, mentoring = request.GET.get("industry", ""), request.GET.get("mentoring")
    if industry:
        qs = qs.filter(industry__iexact=industry)
    if mentoring:
        qs = qs.filter(mentoring=True)
    return page(request, "web/alumni.html", "people", alumni=qs, industries=sorted(set(AlumniProfile.objects.values_list("industry", flat=True)) - {""}),
                f={"industry": industry, "mentoring": bool(mentoring)}, startups=[])


@login_required
@require_POST
def mentor_request(request, username):
    mentor = get_object_or_404(User, username=username, alumni__mentoring=True)
    Mentorship.objects.get_or_create(mentor=mentor, student=request.user, defaults={"message": request.POST.get("message", "")[:300]})
    messages.success(request, f"Request sent to {mentor.display}.")
    return redirect("web:profile", username)


@login_required
@require_POST
def endorse(request, username):
    student = get_object_or_404(User, username=username, role="student")
    if request.user.role != "alumni":
        messages.error(request, "Only alumni can endorse a student.")
    else:
        e, new = Endorsement.objects.get_or_create(alumnus=request.user, student=student, defaults={"note": request.POST.get("note", "")[:200]})
        if new:
            S.anchor_endorsement(e)
            messages.success(request, "Endorsement recorded on the ledger.")
    return redirect("web:profile", username)


# ----------------------------------------------------------------------------- schools
@login_required
def schools(request):
    board = S.school_board()
    view = request.GET.get("view") if request.GET.get("view") in ("table", "cards", "bars") else "table"
    return page(request, "web/schools.html", "schools", board=board, view=view, top=board[0] if board else None)


@login_required
def school_detail(request, code):
    board = S.school_board()
    row = next((r for r in board if r["school"].code == code.upper()), None)
    if not row:
        raise Http404
    return page(request, "web/school.html", "schools", r=row, board=board, suggestions=S.school_suggestions(row, board),
                events=Event.objects.filter(school=row["school"], start_date__gte=timezone.localdate())[:5])


# ----------------------------------------------------------------------------- calendar
@login_required
def calendar_view(request):
    today = timezone.localdate()
    try:
        y, m = (int(x) for x in request.GET.get("month", f"{today.year}-{today.month}").split("-"))
        first = date(y, m, 1)
    except (ValueError, TypeError):
        first = today.replace(day=1)
    cat = request.GET.get("category", "")
    qs = Event.objects.select_related("school")
    if cat in csvio.EVENT_CATEGORIES:
        qs = qs.filter(category=cat)
    view = request.GET.get("view") if request.GET.get("view") in ("month", "list") else "month"
    nxt, prv = (first + timedelta(days=32)).replace(day=1), (first - timedelta(days=1)).replace(day=1)
    weeks = []
    if view == "month":
        span = list(qs.filter(start_date__lte=first + timedelta(days=40), end_date__gte=first - timedelta(days=7)) | qs.filter(end_date__isnull=True, start_date__range=(first - timedelta(days=7), first + timedelta(days=40))))
        by = {}
        for e in span:
            d = e.start_date
            while d <= (e.end_date or e.start_date):
                by.setdefault(d, []).append(e)
                d += timedelta(days=1)
        for wk in pycal.Calendar(0).monthdatescalendar(first.year, first.month):
            weeks.append([{"date": d, "in": d.month == first.month, "today": d == today, "events": by.get(d, [])} for d in wk])
    registered = set(request.user.events_registered.values_list("id", flat=True))
    return page(request, "web/calendar.html", "calendar", first=first, weeks=weeks, view=view, cat=cat, categories=csvio.EVENT_CATEGORIES,
                nxt=f"{nxt.year}-{nxt.month}", prv=f"{prv.year}-{prv.month}", registered=registered,
                upcoming=qs.filter(start_date__gte=today)[:40] if view == "list" else qs.filter(start_date__gte=today)[:6], today=today)


@login_required
@require_POST
def event_register(request, pk):
    e = get_object_or_404(Event, pk=pk)
    (e.attendees.remove if e.attendees.filter(pk=request.user.pk).exists() else e.attendees.add)(request.user)
    return redirect(request.POST.get("next") or "web:calendar")


def _ics_escape(s):
    return (s or "").replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")


@login_required
def calendar_ics(request):
    """One .ics file that Google Calendar and Outlook can import or subscribe to."""
    lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//EduChain Nexus//Calendar//EN", "CALSCALE:GREGORIAN"]
    for e in Event.objects.all():
        end = (e.end_date or e.start_date) + timedelta(days=1)
        lines += ["BEGIN:VEVENT", f"UID:nexus-event-{e.pk}@educhain-nexus", f"DTSTAMP:{timezone.now():%Y%m%dT%H%M%SZ}",
                  f"DTSTART;VALUE=DATE:{e.start_date:%Y%m%d}", f"DTEND;VALUE=DATE:{end:%Y%m%d}", f"SUMMARY:{_ics_escape(e.title)}",
                  f"LOCATION:{_ics_escape(e.location)}", f"DESCRIPTION:{_ics_escape(e.description)}", f"CATEGORIES:{_ics_escape(e.category)}", "END:VEVENT"]
    lines.append("END:VCALENDAR")
    resp = HttpResponse("\r\n".join(lines) + "\r\n", content_type="text/calendar; charset=utf-8")
    resp["Content-Disposition"] = 'attachment; filename="nexus-calendar.ics"'
    return resp


# ----------------------------------------------------------------------------- marketplace
@login_required
def marketplace(request):
    cat = request.GET.get("category", "")
    qs = Listing.objects.select_related("owner", "project")
    if cat in csvio.LISTING_CATEGORIES:
        qs = qs.filter(category=cat)
    return page(request, "web/marketplace.html", "market", listings=qs, categories=csvio.LISTING_CATEGORIES, cat=cat)


@login_required
def listing_detail(request, slug):
    l = get_object_or_404(Listing.objects.select_related("owner", "project"), slug=slug)
    if request.method == "POST":
        Interest.objects.create(listing=l, user=request.user, message=request.POST.get("message", "")[:400])
        messages.success(request, "Your interest was sent to the owner.")
        return redirect("web:listing", slug)
    return page(request, "web/listing.html", "market", l=l, mine=request.user == l.owner,
                interests=l.interests.select_related("user") if request.user == l.owner or request.user.is_data_admin else [])


# ----------------------------------------------------------------------------- ledger, insights, for you
@login_required
def ledger_view(request):
    q = request.GET.get("q", "").strip().lower()
    found = LedgerBlock.objects.filter(hash__startswith=q).first() if len(q) >= 8 else None
    return page(request, "web/ledger.html", "ledger", blocks=LedgerBlock.objects.order_by("-index")[:25], total=LedgerBlock.objects.count(),
                result=S.verify_ledger(), q=q, found=found, kinds=Counter(LedgerBlock.objects.values_list("kind", flat=True)))


@login_required
def insights(request):
    a = S.analytics()
    chart = {"year": a["year"], "prevYear": a["year"] - 1, "months": a["months"],
             "langs": [{k: r[k] for k in ("label", "prev", "cur")} for r in a["langs"]],
             "cats": [{k: r[k] for k in ("label", "prev", "cur")} for r in a["cats"]]}
    return page(request, "web/insights.html", "insights", a=a, chart=chart)


@login_required
def for_you(request):
    return page(request, "web/foryou.html", "foryou", rec=S.recommendations(request.user), m=S.metrics_for(request.user.id))
