import hashlib

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.http import FileResponse, Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from engine import ziputil
from hub import appstore
from hub.models import AppPackage, Project, audit


def _tags(raw):
    return [t.strip()[:30] for t in raw.split(",") if t.strip()][:10]


def _read_upload(request):
    """The uploaded zip as bytes, or None after adding an error message."""
    f = request.FILES.get("file")
    if not f:
        messages.error(request, "Choose a .zip file first.")
        return None
    if f.size > ziputil.MAX_UPLOAD:
        messages.error(request, f"That file is larger than {ziputil.MAX_UPLOAD // (1024 * 1024)} MB. Remove build outputs and dependency folders, then zip again.")
        return None
    return f.read()


@login_required
def apps_list(request):
    q = request.GET.get("q", "").strip()[:80]
    qs = AppPackage.objects.select_related("owner", "owner__profile__school").prefetch_related("versions")
    if q:
        qs = qs.filter(Q(title__icontains=q) | Q(description__icontains=q) | Q(owner__username__icontains=q))
    mine = request.GET.get("mine")
    if mine:
        qs = qs.filter(owner=request.user)
    return render(request, "web/apps.html", {"nav": "apps", "apps": qs[:60], "q": q, "mine": bool(mine)})


@login_required
def app_upload(request):
    projects = Project.objects.filter(owner=request.user)
    if request.method == "POST":
        title = request.POST.get("title", "").strip()[:120]
        data = _read_upload(request) if title else None
        if not title:
            messages.error(request, "Give the app a title.")
        elif data is not None:
            project = projects.filter(pk=request.POST.get("project") or 0).first()
            try:
                pkg = appstore.create_package(request.user, title, request.POST.get("description", "")[:600], _tags(request.POST.get("tags", "")), data, project)
            except appstore.Refused as e:
                messages.error(request, str(e))
            else:
                audit(request.user, "app.upload", {"app": pkg.pk, "size": len(data)}, request)
                messages.success(request, "Uploaded. Other members can now view, edit and download it.")
                return redirect("web:app", pkg.pk)
    return render(request, "web/app_upload.html", {"nav": "apps", "projects": projects, "limit_mb": ziputil.MAX_UPLOAD // (1024 * 1024)})


@login_required
def app_detail(request, pk):
    pkg = get_object_or_404(AppPackage.objects.select_related("owner", "owner__profile__school", "project"), pk=pk)
    latest = pkg.latest
    if not latest:
        raise Http404
    rows = ziputil.depth_rows(latest.manifest)
    path = request.GET.get("file", "")
    shown = None
    if path:
        info = next((r for r in rows if r["name"] == path and not r["dir"]), None)
        if info:
            try:
                text = ziputil.preview_text(appstore.read_bytes(latest), path)
            except (ziputil.ZipRejected, OSError):
                text = None
            shown = {"path": path, "text": text, "size": info["size"], "editable": text is not None and info["size"] <= ziputil.MAX_EDIT}
    return render(request, "web/app_detail.html", {
        "nav": "apps", "pkg": pkg, "latest": latest, "rows": rows, "shown": shown, "versions": pkg.versions.select_related("uploaded_by")[:30],
        "can_edit": appstore.can_edit(request.user, pkg), "can_manage": appstore.can_manage(request.user, pkg), "root": ziputil.top_level(latest.manifest)})


@login_required
def app_download(request, pk):
    pkg = get_object_or_404(AppPackage, pk=pk)
    num = request.GET.get("v", "")
    v = pkg.versions.filter(number=num).first() if num.isdigit() else pkg.latest
    if not v:
        raise Http404
    AppPackage.objects.filter(pk=pk).update(downloads=pkg.downloads + 1)
    audit(request.user, "app.download", {"app": pkg.pk, "version": v.number}, request)
    try:
        fh = v.file.open("rb")
    except OSError:
        raise Http404("The stored file is missing.") from None
    resp = FileResponse(fh, as_attachment=True, filename=appstore.download_name(pkg, v), content_type="application/zip")
    resp["X-Content-Type-Options"] = "nosniff"
    resp["Content-Security-Policy"] = "sandbox"
    return resp


@login_required
def app_edit(request, pk):
    pkg = get_object_or_404(AppPackage.objects.select_related("owner"), pk=pk)
    latest = pkg.latest
    path = request.POST.get("file") or request.GET.get("file", "")
    if not appstore.can_edit(request.user, pkg):
        messages.error(request, "The owner has not allowed edits to this app. You can still view and download it.")
        return redirect("web:app", pk)
    data = appstore.read_bytes(latest)
    try:
        current, truncated = ziputil.read_member(data, path, ziputil.MAX_EDIT)
        text = current.decode("utf-8") if ziputil.looks_text(path, current) and not truncated else None
    except (ziputil.ZipRejected, UnicodeDecodeError):
        text = None
    if text is None:
        messages.error(request, "That file cannot be edited here. Only text files up to 512 KB can. Download the app to change other files.")
        return redirect("web:app", pk)
    base = hashlib.sha256(current).hexdigest()
    if request.method == "POST":
        try:
            v = appstore.edit_file(pkg, request.user, path, request.POST.get("content", ""), request.POST.get("base", ""), request.POST.get("note", ""))
        except appstore.Refused as e:
            messages.error(request, str(e))
            return render(request, "web/app_edit.html", {"nav": "apps", "pkg": pkg, "path": path, "text": request.POST.get("content", ""), "base": request.POST.get("base", ""),
                                                        "note": request.POST.get("note", "")})
        audit(request.user, "app.edit", {"app": pkg.pk, "file": path, "version": v.number}, request)
        messages.success(request, f"Saved as version {v.number}. The earlier version is kept.")
        return redirect(f"/apps/{pk}/?file={path}")
    return render(request, "web/app_edit.html", {"nav": "apps", "pkg": pkg, "path": path, "text": text, "base": base, "note": ""})


@login_required
@require_POST
def app_new_version(request, pk):
    pkg = get_object_or_404(AppPackage, pk=pk)
    data = _read_upload(request)
    if data is not None:
        try:
            v = appstore.add_version(pkg, request.user, data, request.POST.get("note", ""))
        except appstore.Refused as e:
            messages.error(request, str(e))
        else:
            audit(request.user, "app.version", {"app": pkg.pk, "version": v.number}, request)
            messages.success(request, f"Saved as version {v.number}.")
    return redirect("web:app", pk)


@login_required
@require_POST
def app_settings(request, pk):
    pkg = get_object_or_404(AppPackage, pk=pk)
    if not appstore.can_manage(request.user, pkg):
        messages.error(request, "Only the owner can change these settings.")
    else:
        pkg.title = request.POST.get("title", pkg.title).strip()[:120] or pkg.title
        pkg.description = request.POST.get("description", "")[:600]
        pkg.tags = _tags(request.POST.get("tags", ""))
        pkg.open_edit = request.POST.get("open_edit") == "on"
        pkg.save()
        messages.success(request, "Saved.")
    return redirect("web:app", pk)


@login_required
@require_POST
def app_restore(request, pk, number):
    pkg = get_object_or_404(AppPackage, pk=pk)
    try:
        v = appstore.restore(pkg, request.user, number)
    except appstore.Refused as e:
        messages.error(request, str(e))
    else:
        audit(request.user, "app.restore", {"app": pkg.pk, "from": number, "version": v.number}, request)
        messages.success(request, f"Version {number} restored as version {v.number}.")
    return redirect("web:app", pk)


@login_required
@require_POST
def app_delete(request, pk):
    pkg = get_object_or_404(AppPackage, pk=pk)
    if not appstore.can_manage(request.user, pkg):
        messages.error(request, "Only the owner can remove this app.")
        return redirect("web:app", pk)
    audit(request.user, "app.delete", {"app": pkg.pk, "title": pkg.title}, request)
    appstore.delete_package(pkg)
    messages.success(request, "App removed.")
    return redirect("web:apps")
