from django.conf import settings
from django.contrib import messages
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from django.core.cache import cache
from django.core.exceptions import PermissionDenied
from django.core.mail import send_mail
from django.db import transaction
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from hub.models import AlumniProfile, Profile, audit
from .forms import RegisterForm

User = get_user_model()
RATE = 5          # registrations per IP per hour


def _ip(request):
    fwd = request.META.get("HTTP_X_FORWARDED_FOR", "")
    return (fwd.split(",")[0].strip() if fwd else request.META.get("REMOTE_ADDR")) or "unknown"


def register(request):
    if request.user.is_authenticated:
        return redirect("web:explore")
    key = f"reg:{_ip(request)}"
    form = RegisterForm(request.POST or None)
    if request.method == "POST":
        if cache.get(key, 0) >= RATE:
            form.add_error(None, "Too many registrations from this connection. Try again in an hour.")
        elif form.is_valid():
            d = form.cleaned_data
            with transaction.atomic():
                u = User(username=d["username"], first_name=d["first_name"], last_name=d["last_name"], email=d["email"], role=d["role"],
                         status=User.Status.PENDING, is_active=False, reg_note=d["note"])
                u.set_password(d["password1"])
                u.save()
                Profile.objects.create(user=u, school=d["school"])
                if d["role"] == "alumni":
                    AlumniProfile.objects.create(user=u, graduation_year=d["graduation_year"])
            cache.set(key, cache.get(key, 0) + 1, 3600)
            audit(u, "register", {"username": u.username, "role": u.role}, request)
            return redirect("web:register_done")
    return render(request, "web/register.html", {"form": form})


def register_done(request):
    return render(request, "web/register_done.html")


def _admin_only(request):
    if not request.user.is_data_admin:
        raise PermissionDenied


@login_required
def registrations(request):
    _admin_only(request)
    show = request.GET.get("show", "pending")
    qs = User.objects.exclude(status="approved") if show == "all" else User.objects.filter(status="pending")
    qs = qs.select_related("profile__school", "alumni").order_by("-registered_at")
    recent = User.objects.filter(decided_at__isnull=False).select_related("decided_by").order_by("-decided_at")[:10]
    return render(request, "web/registrations.html", {"nav": "regs", "people": qs, "show": show, "recent": recent,
                                                     "pending": User.objects.filter(status="pending").count()})


@login_required
@require_POST
def decide(request, pk, action):
    _admin_only(request)
    u = get_object_or_404(User, pk=pk, status="pending")
    note = request.POST.get("note", "").strip()[:200]
    if action == "approve":
        u.status, u.is_active = User.Status.APPROVED, True
    elif action == "reject":
        u.status, u.is_active = User.Status.REJECTED, False
    else:
        raise PermissionDenied
    u.decided_at, u.decided_by, u.decision_note = timezone.now(), request.user, note
    u.save()
    audit(request.user, f"registration.{action}", {"user": u.username}, request)
    if u.email:
        body = ("Your Nexus registration was approved. You can now sign in." if action == "approve"
                else "Your Nexus registration was not approved." + (f"\nReason: {note}" if note else ""))
        send_mail("Your Nexus registration", body, getattr(settings, "DEFAULT_FROM_EMAIL", None), [u.email], fail_silently=True)
    messages.success(request, f"{u.display} {'approved' if action == 'approve' else 'not approved'}.")
    return redirect("web:registrations")
